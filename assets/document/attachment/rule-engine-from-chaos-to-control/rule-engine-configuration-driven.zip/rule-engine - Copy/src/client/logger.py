from typing import Protocol


class Logger(Protocol):
    def log(self, message: str) -> None: pass


# Multiple implementations demonstrate flexibility
class ConsoleLogger:
    def log(self, message: str) -> None:
        print(f"[CONSOLE] {message}")


class StructuredLogger(Logger):
    def log(self, message: str) -> None:
        print(f"structured [CONSOLE] {message}")


class MetricsLogger(Logger):
    def __init__(self):
        print("init")

    def log(self, message: str) -> None:
        print(f"metric logger")
