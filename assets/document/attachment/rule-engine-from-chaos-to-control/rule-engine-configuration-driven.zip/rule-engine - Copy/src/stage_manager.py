from concurrent.futures import ThreadPoolExecutor, as_completed
import time
from dataclasses import dataclass
from datetime import datetime
from typing import Dict, List, Any

from src.dependency_resolver import DependencyResolver
from src.rule_configuration_loader import RuleConfigurationLoader
from src.rule_executor import ExecutionContext
from src.rules.basic.rule import RuleResult
from src.rules.staged.staged_rule import ExecutionStage, StagedRule


@dataclass
class StageExecutionResult:
    """Results from executing a single stage"""
    stage: ExecutionStage
    success: bool
    rule_results: Dict[str, RuleResult]
    execution_time_ms: int
    failed_rules: List[str]
    skipped_rules: List[str]
    error_messages: Dict[str, str]


class StageManager:
    """Manages the execution of rules within individual stages"""

    def __init__(self, config_loader: RuleConfigurationLoader):
        self.config_loader = config_loader
        self.global_results = {}  # Accumulates results across all stages

    def execute_stage(self, stage: ExecutionStage,
                      config: Dict[str, Any],
                      context: ExecutionContext) -> StageExecutionResult:
        """Execute all rules for a specific stage"""
        start_time = time.time()

        # Load rules for this stage
        rules = self.config_loader.load_rules_for_stage(stage, config)

        if not rules:
            return self._create_empty_result(stage, start_time)

        stage_config = config["stages"][stage.value]

        # Execute rules based on stage configuration
        if stage_config.get("parallel_execution", False):
            stage_results = self._execute_rules_parallel(
                rules, context, stage_config
            )
        else:
            stage_results = self._execute_rules_sequential(
                rules, context, stage_config
            )

        # Update global results for cross-stage dependencies
        self.global_results.update(stage_results)

        execution_time = int((time.time() - start_time) * 1000)

        return StageExecutionResult(
            stage=stage,
            success=self._is_stage_successful(stage_results),
            rule_results=stage_results,
            execution_time_ms=execution_time,
            failed_rules=[r for r, result in stage_results.items()
                          if result == RuleResult.FAIL],
            skipped_rules=[r for r, result in stage_results.items()
                           if result == RuleResult.SKIP],
            error_messages={}  # Would be populated from exception handling
        )

    def _execute_rules_sequential(self, rules: List[StagedRule],
                                  context: ExecutionContext,
                                  stage_config: Dict[str, Any]) -> Dict[str, RuleResult]:
        """Execute rules sequentially with dependency resolution"""
        resolver = DependencyResolver()

        # Build dependency graph for this stage
        for rule in rules:
            resolver.add_rule(rule)

        execution_order = resolver.get_execution_order()
        results = self.global_results.copy()
        fail_fast = stage_config.get("fail_fast", True)

        for rule_id in execution_order:
            rule = next(r for r in rules if r.rule_id == rule_id)

            # Check if rule can execute given current results
            if rule.can_execute_in_stage(rule.stage, set(), results):
                try:
                    result = rule.execute(context.data)
                    results[rule_id] = result

                    if fail_fast and result == RuleResult.FAIL:
                        # Mark remaining rules as skipped
                        remaining_rules = execution_order[execution_order.index(rule_id) + 1:]
                        for remaining_rule_id in remaining_rules:
                            results[remaining_rule_id] = RuleResult.SKIP
                        break

                except Exception as e:
                    results[rule_id] = RuleResult.FAIL
                    if fail_fast:
                        break
            else:
                results[rule_id] = RuleResult.SKIP

        return results

    def _execute_rules_parallel(self, rules: List[StagedRule],
                                context: ExecutionContext,
                                stage_config: Dict[str, Any]) -> Dict[str, RuleResult]:
        """Execute independent rules in parallel for performance"""
        max_workers = min(len(rules), stage_config.get("max_parallel_rules", 4))
        timeout = stage_config.get("timeout_seconds", 30)
        results = self.global_results.copy()

        # Identify rules that can run in parallel (no dependencies within stage)
        independent_rules = [r for r in rules if not r.dependencies]
        dependent_rules = [r for r in rules if r.dependencies]

        # Execute independent rules in parallel
        if independent_rules:
            with ThreadPoolExecutor(max_workers=max_workers) as executor:
                future_to_rule = {
                    executor.submit(self._execute_single_rule, rule, context): rule
                    for rule in independent_rules
                    if rule.can_execute_in_stage(rule.stage, set(), results)
                }

                try:
                    for future in as_completed(future_to_rule, timeout=timeout):
                        rule = future_to_rule[future]
                        try:
                            result = future.result()
                            results[rule.rule_id] = result
                        except Exception as e:
                            results[rule.rule_id] = RuleResult.FAIL
                except TimeoutError:
                    # Handle timeout by marking incomplete rules as failed
                    for future, rule in future_to_rule.items():
                        if not future.done():
                            future.cancel()
                            results[rule.rule_id] = RuleResult.FAIL

        # Execute dependent rules sequentially after parallel execution
        if dependent_rules:
            sequential_results = self._execute_rules_sequential(
                dependent_rules, context, stage_config
            )
            results.update(sequential_results)

        return results

    def _execute_single_rule(self, rule: StagedRule,
                             context: ExecutionContext) -> RuleResult:
        """Execute a single rule with error handling"""
        try:
            return rule.execute(context.data)
        except Exception:
            return RuleResult.FAIL

    def _is_stage_successful(self, results: Dict[str, RuleResult]) -> bool:
        """Determine if a stage execution was successful"""
        return all(result in [RuleResult.PASS, RuleResult.SKIP]
                   for result in results.values())

    def _create_empty_result(self, stage: ExecutionStage,
                             start_time: float) -> StageExecutionResult:
        """Create result for stages with no rules"""
        execution_time = int((time.time() - start_time) * 1000)
        return StageExecutionResult(
            stage=stage,
            success=True,
            rule_results={},
            execution_time_ms=execution_time,
            failed_rules=[],
            skipped_rules=[],
            error_messages={}
        )