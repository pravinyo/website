from src.rules.basic.rule import RuleResult
from src.rules.staged.staged_rule import StagedRule, ExecutionStage


class TrimWhitespaceRule(StagedRule):
    """Preprocessing rule that normalizes string data"""

    def __init__(self, rule_id: str, field_name: str):
        super().__init__(rule_id, ExecutionStage.PREPROCESSING)
        self.field_name = field_name

    def execute(self, data: dict) -> RuleResult:
        value = data.get(self.field_name)
        if isinstance(value, str):
            # Modify data in place during preprocessing
            data[self.field_name] = value.strip()
            return RuleResult.PASS
        return RuleResult.SKIP
