from typing import List

from src.rules.basic.rule import RuleResult
from src.rules.staged.staged_rule import StagedRule, ExecutionStage
from src.services.kyc_service import KYCService


class KYCIdentityRule(StagedRule):
    """Compliance rule that performs identity verification"""

    def __init__(self, rule_id: str, kyc_service: KYCService,
                 stage: ExecutionStage,
                 verification_level: str = "standard",
                 document_types: List[str] = None,
                 dependencies: List[str] = None,
                 cross_stage_dependencies: List[str] = None):
        super().__init__(rule_id, stage, dependencies, cross_stage_dependencies)
        self.kyc_service = kyc_service
        self.verification_level = verification_level
        self.document_types = document_types or ["drivers_license"]

    def execute(self, data: dict) -> RuleResult:
        try:
            verification_result = self.kyc_service.verify_identity(
                first_name=data.get("first_name"),
                last_name=data.get("last_name"),
                date_of_birth=data.get("date_of_birth"),
                address=data.get("address"),
                verification_level=self.verification_level,
                accepted_documents=self.document_types
            )

            # Store verification details for downstream rules
            data["kyc_verification_id"] = verification_result["verification_id"]
            data["identity_confidence_score"] = verification_result["confidence_score"]

            return RuleResult.PASS if verification_result["verified"] else RuleResult.FAIL

        except Exception as e:
            # Log the error and fail the rule
            print(f"KYC verification failed: {e}")
            return RuleResult.FAIL
