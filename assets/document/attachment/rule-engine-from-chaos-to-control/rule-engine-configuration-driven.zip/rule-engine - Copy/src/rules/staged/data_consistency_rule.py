from typing import List

from src.rules.basic.rule import RuleResult
from src.rules.staged.staged_rule import StagedRule, ExecutionStage


class DataConsistencyRule(StagedRule):
    """Validates email format - depends on email being present"""

    def __init__(self, rule_id: str, validation_rules: list[dict], stage: ExecutionStage,
                 dependencies: List[str] = None,
                 cross_stage_dependencies: List[str] = None):
        super().__init__(rule_id, stage, dependencies, cross_stage_dependencies)
        self.validation_rules = validation_rules

    def execute(self, data: dict) -> RuleResult:
        return RuleResult.PASS
