from src.rules.basic.rule import Rule, RuleResult


class RequiredFieldRule(Rule):
    """Validates that a field is present and not empty"""

    def __init__(self, rule_id: str, field_name: str):
        super().__init__(rule_id)
        self.field_name = field_name

    def execute(self, data: dict) -> RuleResult:
        value = data.get(self.field_name)

        if value is None or (isinstance(value, str) and not value.strip()):
            return RuleResult.FAIL

        return RuleResult.PASS
