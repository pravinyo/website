from typing import List

from src.rules.basic.rule import Rule, RuleResult
from src.rules.staged.staged_rule import StagedRule, ExecutionStage


class EmailFormatRule(StagedRule):
    """Validates email format - depends on email being present"""
    def __init__(self, rule_id: str, field_name: str, stage: ExecutionStage,
                 dependencies: List[str] = None,
                 cross_stage_dependencies: List[str] = None):
        super().__init__(rule_id, stage, dependencies, cross_stage_dependencies)
        self.field_name = field_name

    def execute(self, data: dict) -> RuleResult:
        email = data.get(self.field_name)

        if email and '@' in email and '.' in email:
            return RuleResult.PASS

        return RuleResult.FAIL
