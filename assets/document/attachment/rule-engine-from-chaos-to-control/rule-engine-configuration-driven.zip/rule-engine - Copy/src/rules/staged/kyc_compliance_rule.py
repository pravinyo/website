from typing import List

from src.rules.basic.rule import RuleResult
from src.rules.staged.staged_rule import StagedRule, ExecutionStage
from src.services.kyc_service import KYCService


class KYCComplianceRule(StagedRule):
    """Compliance rule that performs expensive external validation"""

    def __init__(self, rule_id: str, kyc_service: KYCService,
                 stage: ExecutionStage,
                 dependencies: List[str] = None,
                 cross_stage_dependencies: List[str] = None):
        super().__init__(rule_id, stage, dependencies, cross_stage_dependencies)
        self.kyc_service = kyc_service

    def execute(self, data: dict) -> RuleResult:
        # This is expensive - only run after data quality validation
        try:
            is_valid = self.kyc_service.validate_identity(
                data["name"], data["address"], data["ssn"]
            )
            return RuleResult.PASS if is_valid else RuleResult.FAIL
        except Exception:
            return RuleResult.FAIL
