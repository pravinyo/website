from typing import List

from src.rules.basic.rule import RuleResult
from src.rules.staged.staged_rule import StagedRule, ExecutionStage


class DataCompletenessRule(StagedRule):
    """Data quality rule that checks for required fields"""

    def __init__(self, rule_id: str, required_fields: List[str]):
        super().__init__(rule_id, ExecutionStage.DATA_QUALITY)
        self.required_fields = required_fields

    def execute(self, data: dict) -> RuleResult:
        missing_fields = [
            field for field in self.required_fields
            if not data.get(field)
        ]
        return RuleResult.PASS if not missing_fields else RuleResult.FAIL
    