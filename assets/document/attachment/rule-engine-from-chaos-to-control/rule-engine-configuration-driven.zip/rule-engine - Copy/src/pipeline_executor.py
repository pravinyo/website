import time
from dataclasses import dataclass
from datetime import datetime
from typing import List, Dict, Any

from src.rule_configuration_loader import RuleConfigurationLoader
from src.rule_executor import ExecutionContext
from src.rules.staged.staged_rule import ExecutionStage
from src.service_container import ServiceContainer
from src.stage_manager import StageExecutionResult, StageManager


@dataclass
class PipelineExecutionResult:
    """Complete results from pipeline execution"""
    success: bool
    executed_stages: List[ExecutionStage]
    stage_results: Dict[ExecutionStage, StageExecutionResult]
    total_execution_time_ms: int
    pipeline_metadata: Dict[str, Any]

    def get_failed_stages(self) -> List[ExecutionStage]:
        """Get stages that failed during execution"""
        return [stage for stage, result in self.stage_results.items()
                if not result.success]

    def get_all_failed_rules(self) -> Dict[ExecutionStage, List[str]]:
        """Get all failed rules organized by stage"""
        return {stage: result.failed_rules
                for stage, result in self.stage_results.items()
                if result.failed_rules}


class ConfigurablePipelineExecutor:
    """Main orchestration engine for stage-aware rule execution"""

    def __init__(self, config: Dict[str, Any],
                 service_container: ServiceContainer):
        self.config = config
        self.config_loader = RuleConfigurationLoader(service_container)
        self.stage_manager = StageManager(self.config_loader)

    def execute_pipeline(self, data: Dict[str, Any],
                         stages: List[ExecutionStage] = None,
                         metadata: Dict[str, Any] = None) -> PipelineExecutionResult:
        """Execute complete pipeline or specific stages"""
        start_time = time.time()

        # Default to all configured stages
        if stages is None:
            stages = [ExecutionStage(stage_name)
                      for stage_name in self.config["stages"].keys()]

        context = ExecutionContext(
            data=data,
            metadata=metadata or {},
            results={}
        )

        executed_stages = []
        stage_results = {}
        stop_on_failure = self.config["execution_settings"].get(
            "stop_on_stage_failure", True
        )

        for stage in stages:
            if stage.value not in self.config["stages"]:
                continue  # Skip unconfigured stages

            stage_config = self.config["stages"][stage.value]
            if not stage_config.get("enabled", True):
                continue  # Skip disabled stages

            # Execute the stage
            result = self.stage_manager.execute_stage(stage, self.config, context)
            stage_results[stage] = result
            executed_stages.append(stage)

            # Check if we should stop on failure
            if stop_on_failure and not result.success:
                break

        total_time = int((time.time() - start_time) * 1000)

        return PipelineExecutionResult(
            success=all(result.success for result in stage_results.values()),
            executed_stages=executed_stages,
            stage_results=stage_results,
            total_execution_time_ms=total_time,
            pipeline_metadata={
                "execution_timestamp": datetime.now().isoformat(),
                "configuration_version": self.config.get("version", "unknown"),
                "total_rules_executed": sum(
                    len(result.rule_results) for result in stage_results.values()
                )
            }
        )

    def execute_single_stage(self, stage: ExecutionStage,
                             data: Dict[str, Any],
                             metadata: Dict[str, Any] = None) -> StageExecutionResult:
        """Execute only a specific stage - useful for debugging and testing"""
        context = ExecutionContext(
            data=data,
            metadata=metadata or {},
            results={}
        )

        return self.stage_manager.execute_stage(stage, self.config, context)

    def validate_configuration(self) -> List[str]:
        """Validate the pipeline configuration for errors"""
        errors = []

        # Check for required configuration sections
        if "stages" not in self.config:
            errors.append("Missing 'stages' configuration section")
            return errors

        if "execution_settings" not in self.config:
            errors.append("Missing 'execution_settings' configuration section")

        # Validate each stage configuration
        for stage_name, stage_config in self.config["stages"].items():
            stage_errors = self._validate_stage_config(stage_name, stage_config)
            errors.extend(stage_errors)

        return errors

    def _validate_stage_config(self, stage_name: str,
                               stage_config: Dict[str, Any]) -> List[str]:
        """Validate configuration for a single stage"""
        errors = []

        # Check for required stage fields
        if "rules" not in stage_config:
            errors.append(f"Stage '{stage_name}' missing 'rules' section")
            return errors

        # Validate each rule configuration
        for rule_id, rule_config in stage_config["rules"].items():
            if "class" not in rule_config:
                errors.append(f"Rule '{rule_id}' in stage '{stage_name}' missing 'class'")

            rule_class_name = rule_config.get("class")
            if rule_class_name not in self.config_loader.rule_registry:
                errors.append(f"Unknown rule class '{rule_class_name}' in rule '{rule_id}'")

        return errors

    def get_stage_summary(self) -> Dict[str, Any]:
        """Get summary information about configured stages"""
        summary = {}

        for stage_name, stage_config in self.config["stages"].items():
            summary[stage_name] = {
                "enabled": stage_config.get("enabled", True),
                "rule_count": len(stage_config.get("rules", {})),
                "parallel_execution": stage_config.get("parallel_execution", False),
                "fail_fast": stage_config.get("fail_fast", True),
                "timeout_seconds": stage_config.get("timeout_seconds", 30)
            }

        return summary