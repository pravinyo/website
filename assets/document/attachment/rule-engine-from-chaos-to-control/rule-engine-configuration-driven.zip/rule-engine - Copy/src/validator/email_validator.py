from src.client.api_client import ApiClient
from src.client.logger import Logger
from src.rules.basic.rule import Rule, RuleResult
from src.service_container import ServiceContainer


class EmailValidator(Rule):
    def execute(self, data: dict) -> RuleResult:
        pass


class ApiEmailValidator(EmailValidator):
    def __init__(self, api_client, logger: Logger, rule_id: str):
        super().__init__(rule_id)
        self.api_client = api_client
        self.logger = logger

    def execute(self, data: dict) -> RuleResult:
        try:
            self.logger.log(f"Validating email via API: {data["email"]}")
            # API call would happen here
            return RuleResult.PASS if '@' in data["email"] else RuleResult.FAIL
        except Exception as e:
            self.logger.log(f"API validation failed: {e}")
            return RuleResult.FAIL


class HybridEmailValidator(EmailValidator):
    def __init__(self, container: ServiceContainer, rule_id: str):
        super().__init__(rule_id)
        self.api_client = container.resolve(ApiClient)
        self.logger = container.resolve(Logger, "metrics")

    def execute(self, data: dict):
        if self.validate(data):
            return RuleResult.PASS
        return RuleResult.FAIL

    def validate(self, data: dict):
        try:
            return '.' in data["email"]
        except Exception as e:
            self.logger.log(f"API validation failed: {e}")
            return False