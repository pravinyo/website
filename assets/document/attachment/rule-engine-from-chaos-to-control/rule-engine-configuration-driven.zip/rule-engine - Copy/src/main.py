from src.pipeline_config import CUSTOMER_ONBOARDING_CONFIG
from src.pipeline_executor import ConfigurablePipelineExecutor
from src.rules.staged.staged_rule import ExecutionStage
from src.service_container import ServiceContainer
from src.services.kyc_service import KYCService, KYCServiceImpl


def setup_customer_services(container: ServiceContainer):
    container.register(KYCService, KYCServiceImpl,name='kyc')

def process_customer_application():
    """Demonstrate the complete customer onboarding pipeline"""

    # Setup service container with mock services
    container = ServiceContainer()
    setup_customer_services(container)

    # Create pipeline executor
    executor = ConfigurablePipelineExecutor(CUSTOMER_ONBOARDING_CONFIG, container)

    # Validate configuration before execution
    config_errors = executor.validate_configuration()
    if config_errors:
        print("Configuration errors found:")
        for error in config_errors:
            print(f"  - {error}")
        return None

    # Sample customer data
    customer_data = {
        "name": "  John Michael Smith  ",  # Has whitespace to be trimmed
        "first_name": "John",
        "last_name": "Smith",
        "email": "JOHN.SMITH@EXAMPLE.COM",  # Needs normalization
        "phone": "5551234567",
        "address": "123 Main St, Apt 2B",
        "city": "New York",
        "state": "NY",
        "zip_code": "10001",
        "date_of_birth": "1985-03-15",
        "ssn": "123-45-6789"
    }

    print("🚀 Starting customer onboarding pipeline...")
    print(f"📋 Pipeline configuration version: {CUSTOMER_ONBOARDING_CONFIG['version']}")
    print()

    # Execute the complete pipeline
    result = executor.execute_pipeline(
        data=customer_data,
        metadata={
            "application_id": "APP-2024-001234",
            "channel": "web_application",
            "referral_source": "organic_search"
        }
    )

    # Display comprehensive results
    print("📊 PIPELINE EXECUTION RESULTS")
    print("=" * 50)
    print(f"Overall Success: {'✅ PASS' if result.success else '❌ FAIL'}")
    print(f"Total Execution Time: {result.total_execution_time_ms}ms")
    print(f"Stages Executed: {len(result.executed_stages)}")
    print()

    # Stage-by-stage breakdown
    for stage in result.executed_stages:
        stage_result = result.stage_results[stage]
        status_icon = "✅" if stage_result.success else "❌"

        print(f"{status_icon} {stage.value.upper()} ({stage_result.execution_time_ms}ms)")
        print(f"   Rules Executed: {len(stage_result.rule_results)}")

        if stage_result.failed_rules:
            print(f"   Failed Rules: {', '.join(stage_result.failed_rules)}")

        if stage_result.skipped_rules:
            print(f"   Skipped Rules: {', '.join(stage_result.skipped_rules)}")

        print()

    # Failed rules summary
    failed_rules = result.get_all_failed_rules()
    if failed_rules:
        print("❌ FAILED RULES BY STAGE")
        print("-" * 30)
        for stage, rules in failed_rules.items():
            print(f"{stage.value}: {', '.join(rules)}")
        print()

    # Final customer data (after all transformations)
    print("📋 FINAL CUSTOMER DATA")
    print("-" * 25)
    for key, value in customer_data.items():
        print(f"{key}: {value}")

    return result


# Example of executing only specific stages
def process_data_quality_only():
    """Demonstrate executing only the data quality stage"""

    container = ServiceContainer()
    setup_customer_services(container)
    executor = ConfigurablePipelineExecutor(CUSTOMER_ONBOARDING_CONFIG, container)

    customer_data = {
        "first_name": "John",
        "last_name": "Smith",
        "email": "john.smith@example.com",
        "phone": "+15551234567"
    }

    print("🔍 Running DATA QUALITY stage only...")

    # Execute only the data quality stage
    result = executor.execute_single_stage(
        ExecutionStage.DATA_QUALITY,
        customer_data,
        metadata={"stage_test": True}
    )

    print(f"Data Quality Result: {'✅ PASS' if result.success else '❌ FAIL'}")
    print(f"Execution Time: {result.execution_time_ms}ms")

    if result.failed_rules:
        print(f"Failed Rules: {', '.join(result.failed_rules)}")

    return result

if __name__ == "__main__":
    process_data_quality_only()