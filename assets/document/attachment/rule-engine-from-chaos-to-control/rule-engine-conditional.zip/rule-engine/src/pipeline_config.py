# Pipeline configuration as a Python dictionary
PIPELINE_CONFIG = {
    "stages": {
        "preprocessing": {
            "enabled": True,
            "fail_fast": False,  # Continue processing even if some preprocessing fails
            "parallel_execution": True,
            "timeout_seconds": 10,
            "rules": {
                "trim_name": {
                    "class": "TrimWhitespaceRule",
                    "params": {"field_name": "name"}
                },
                "trim_email": {
                    "class": "TrimWhitespaceRule",
                    "params": {"field_name": "email"}
                },
                "normalize_phone": {
                    "class": "PhoneNormalizationRule",
                    "params": {"field_name": "phone", "country_code": "US"}
                }
            }
        },
        "data_quality": {
            "enabled": True,
            "fail_fast": True,  # Stop immediately on data quality failures
            "parallel_execution": False,
            "timeout_seconds": 15,
            "rules": {
                "required_fields": {
                    "class": "DataCompletenessRule",
                    "params": {"required_fields": ["name", "email", "phone"]}
                },
                "email_format": {
                    "class": "EmailFormatValidationRule",
                    "params": {"field_name": "email"},
                    "dependencies": ["required_fields"]
                },
                "phone_format": {
                    "class": "PhoneFormatValidationRule",
                    "params": {"field_name": "phone"},
                    "dependencies": ["required_fields"]
                }
            }
        },
        "compliance": {
            "enabled": True,
            "fail_fast": True,
            "parallel_execution": True,  # Independent compliance checks can run in parallel
            "timeout_seconds": 60,  # Compliance checks are slower
            "rules": {
                "kyc_validation": {
                    "class": "KYCComplianceRule",
                    "params": {"service_name": "primary_kyc"},
                    "cross_stage_dependencies": ["required_fields", "email_format"]
                },
                "sanctions_screening": {
                    "class": "SanctionsScreeningRule",
                    "params": {"screening_level": "enhanced"},
                    "cross_stage_dependencies": ["required_fields"]
                },
                "pep_screening": {
                    "class": "PEPScreeningRule",
                    "params": {"risk_threshold": "medium"},
                    "cross_stage_dependencies": ["kyc_validation"]
                }
            }
        },
        "business_rules": {
            "enabled": True,
            "fail_fast": False,  # Collect all business rule violations
            "parallel_execution": True,
            "timeout_seconds": 30,
            "rules": {
                "credit_score_check": {
                    "class": "CreditScoreValidationRule",
                    "params": {"minimum_score": 650, "bureau": "experian"},
                    "cross_stage_dependencies": ["kyc_validation"]
                },
                "income_verification": {
                    "class": "IncomeVerificationRule",
                    "params": {"verification_method": "bank_statements"},
                    "cross_stage_dependencies": ["kyc_validation"]
                },
                "debt_to_income_ratio": {
                    "class": "DebtToIncomeRule",
                    "params": {"max_ratio": 0.43},
                    "dependencies": ["income_verification"]
                }
            }
        }
    },
    "execution_settings": {
        "stop_on_stage_failure": True,  # Stop pipeline if any stage fails
        "enable_audit_logging": True,
        "max_parallel_rules": 4,
        "default_timeout": 30
    }
}

CUSTOMER_ONBOARDING_CONFIG = {
    "version": "2.1.0",
    "stages": {
        "preprocessing": {
            "enabled": True,
            "fail_fast": False,
            "parallel_execution": True,
            "timeout_seconds": 5,
            "max_parallel_rules": 6,
            "rules": {
                "trim_whitespace": {
                    "class": "MultiFieldTrimRule",
                    "params": {
                        "fields": ["name", "email", "address", "city", "state"]
                    }
                }
            }
        },

        "data_quality": {
            "enabled": True,
            "fail_fast": True,
            "parallel_execution": False,
            "timeout_seconds": 10,
            "rules": {
                "required_personal_info": {
                    "class": "RequiredFieldsRule",
                    "params": {
                        "required_fields": ["first_name", "last_name", "email", "phone"],
                        "field_descriptions": {
                            "first_name": "Customer first name",
                            "last_name": "Customer last name",
                            "email": "Valid email address",
                            "phone": "US phone number"
                        }
                    }
                },
                "email_format_validation": {
                    "class": "EmailFormatRule",
                    "params": {
                        "field_name": "email"
                    },
                    "dependencies": ["required_personal_info"]
                },
                "phone_format_validation": {
                    "class": "PhoneFormatRule",
                    "params": {
                        "field_name": "phone"
                    },
                    "dependencies": ["required_personal_info"]
                },
                "data_consistency_check": {
                    "class": "DataConsistencyRule",
                    "params": {
                        "validation_rules": [
                            {
                                "fields": ["state", "zip_code"],
                                "validator": "state_zip_consistency"
                            },
                            {
                                "fields": ["area_code", "phone"],
                                "validator": "area_code_consistency"
                            }
                        ]
                    },
                    "dependencies": ["email_format_validation", "phone_format_validation"]
                }
            }
        },

        "compliance": {
            "enabled": True,
            "fail_fast": False,  # Collect all compliance violations
            "parallel_execution": True,
            "timeout_seconds": 45,
            "max_parallel_rules": 3,
            "rules": {
                "kyc_identity_verification": {
                    "class": "KYCIdentityRule",
                    "params": {
                        "kyc_service": "service:KYCService:kyc",
                        "verification_level": "enhanced",
                        "document_types": ["drivers_license", "passport", "state_id"]
                    },
                    "cross_stage_dependencies": ["required_personal_info", "data_consistency_check"]
                },
                "kyc_compliance": {
                    "class": "KYCComplianceRule",
                    "params": {
                        "kyc_service": "service:KYCService:kyc",

                    },
                    "cross_stage_dependencies": ["data_consistency_check"]
                },
            }
        },

        "post_processing": {
            "enabled": True,
            "fail_fast": False,
            "parallel_execution": True,
            "timeout_seconds": 15,
            "rules": {
                "risk_score_calculation": {
                    "class": "RiskScoreAggregationRule",
                    "params": {
                        "scoring_model": "composite_v2",
                        "weight_factors": {
                            "credit_score": 0.4,
                            "aml_risk": 0.3,
                            "geographic_risk": 0.2,
                            "identity_confidence": 0.1
                        }
                    }
                },
            }
        }
    },

    "execution_settings": {
        "stop_on_stage_failure": True,
        "enable_audit_logging": True,
        "max_parallel_rules": 8,
        "default_timeout": 30,
        "retry_failed_rules": False,
        "performance_monitoring": {
            "enabled": True,
            "slow_rule_threshold_ms": 5000,
            "alert_on_timeout": True
        }
    }
}