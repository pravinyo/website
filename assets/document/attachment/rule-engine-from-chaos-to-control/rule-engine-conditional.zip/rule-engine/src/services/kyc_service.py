from abc import ABC, abstractmethod


class KYCService(ABC):
    @abstractmethod
    def validate_identity(self, name:str, address:str, ssn:str) -> bool:
        pass

    @abstractmethod
    def verify_identity(self, first_name:str, last_name:str, date_of_birth:str, address:str, verification_level:str, accepted_documents:list[str]) -> dict:
        pass


class KYCServiceImpl(KYCService):
    def __init__(self):
        print("kyc init")

    def validate_identity(self, name: str, address: str, ssn: str) -> bool:
        return True

    def verify_identity(self, first_name: str, last_name: str, date_of_birth: str, address: str,
                        verification_level: str, accepted_documents: list[str]) -> dict:
        return {
            "verification_id": "abc",
            "confidence_score": "1.0",
            "verified": True
        }