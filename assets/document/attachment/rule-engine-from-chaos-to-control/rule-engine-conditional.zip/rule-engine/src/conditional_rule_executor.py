import json
from collections import defaultdict, deque
from typing import Dict

from src.rule_execution_result import RuleExecutionResult, RuleResult
from src.rules.conditional.conditional_rule import ConditionalRule


class ConditionalRuleExecutor:
    """Executor that handles conditional rule execution"""

    def __init__(self):
        self.rules = {}
        self.execution_order = []

    def register_rule(self, rule: ConditionalRule):
        """Register a rule for execution"""
        self.rules[rule.rule_id] = rule
        self._calculate_execution_order()

    def _calculate_execution_order(self):
        """Calculate execution order using topological sort"""
        # Build dependency graph
        graph = defaultdict(list)
        in_degree = defaultdict(int)

        # Initialize all rules with 0 in-degree
        for rule_id in self.rules:
            in_degree[rule_id] = 0

        # Build the graph
        for rule_id, rule in self.rules.items():
            all_deps = rule.dependencies + list(rule.conditional_dependencies.keys())
            for dep in all_deps:
                if dep in self.rules:  # Only include registered dependencies
                    graph[dep].append(rule_id)
                    in_degree[rule_id] += 1

        # Topological sort
        queue = deque([rule_id for rule_id in in_degree if in_degree[rule_id] == 0])
        self.execution_order = []

        while queue:
            current = queue.popleft()
            self.execution_order.append(current)

            for neighbor in graph[current]:
                in_degree[neighbor] -= 1
                if in_degree[neighbor] == 0:
                    queue.append(neighbor)

    def execute_all(self, data: dict) -> Dict[str, RuleExecutionResult]:
        """Execute all rules with conditional logic"""
        results = {}

        print("🚀 Starting conditional rule execution...")
        print("=" * 50)

        for rule_id in self.execution_order:
            rule = self.rules[rule_id]

            # Check if rule should be skipped
            should_skip, skip_reason = rule.should_skip(results)
            if should_skip:
                results[rule_id] = RuleExecutionResult(
                    result=RuleResult.SKIP,
                    message=skip_reason
                )
                print(f"⏭️  {rule_id}: SKIPPED - {skip_reason}")
                continue

            # Check if rule can execute
            if not rule.can_execute(results):
                results[rule_id] = RuleExecutionResult(
                    result=RuleResult.SKIP,
                    message="Dependencies not met"
                )
                print(f"⏭️  {rule_id}: SKIPPED - Dependencies not met")
                continue

            # Execute the rule
            try:
                result = rule.execute(data)
                results[rule_id] = result

                status_icon = "✅" if result.result == RuleResult.PASS else "❌"
                print(f"{status_icon} {rule_id}: {result.result.value.upper()} - {result.message}")

                if result.result == RuleResult.FAIL and result.failure_data:
                    print(f"   📋 Failure Data: {json.dumps(result.failure_data, indent=6)}")

            except Exception as e:
                results[rule_id] = RuleExecutionResult(
                    result=RuleResult.FAIL,
                    message=f"Execution error: {str(e)}",
                    failure_data={"error": "execution_exception", "details": str(e)}
                )
                print(f"❌ {rule_id}: FAILED - Execution error: {e}")

        return results
