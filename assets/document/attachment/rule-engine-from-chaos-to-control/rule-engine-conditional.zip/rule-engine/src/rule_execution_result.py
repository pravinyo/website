from enum import Enum
from dataclasses import dataclass
from typing import Dict, Any


class RuleResult(Enum):
    PASS = "pass"
    FAIL = "fail"
    SKIP = "skip"


@dataclass
class RuleExecutionResult:
    """Enhanced result with conditional execution data"""
    result: RuleResult
    message: str = ""
    failure_data: Dict[str, Any] = None
    execution_time_ms: int = 0

    def __post_init__(self):
        if self.failure_data is None:
            self.failure_data = {}