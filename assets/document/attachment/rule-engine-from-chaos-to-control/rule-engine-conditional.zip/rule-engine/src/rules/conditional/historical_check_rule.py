import time

from src.rule_execution_result import RuleExecutionResult, RuleResult
from src.rules.conditional.conditional_rule import ConditionalRule


class HistoricalCheckRule(ConditionalRule):
    """First rule in the chain - no dependencies"""

    def __init__(self, rule_id: str = "historical_check"):
        super().__init__(rule_id)

    def execute(self, data: dict) -> RuleExecutionResult:
        start_time = time.time()

        # Simulate historical data validation
        customer_id = data.get("customer_id")
        if not customer_id:
            return RuleExecutionResult(
                result=RuleResult.FAIL,
                message="Customer ID required for historical check",
                failure_data={"error": "missing_customer_id"},
                execution_time_ms=int((time.time() - start_time) * 1000)
            )

        # Simulate checking historical records
        historical_records = data.get("historical_records", [])
        if len(historical_records) > 5:  # Example business rule
            return RuleExecutionResult(
                result=RuleResult.FAIL,
                message="Too many historical records found",
                failure_data={
                    "record_count": len(historical_records),
                    "max_allowed": 5,
                    "customer_id": customer_id
                },
                execution_time_ms=int((time.time() - start_time) * 1000)
            )

        return RuleExecutionResult(
            result=RuleResult.PASS,
            message="Historical check passed",
            execution_time_ms=int((time.time() - start_time) * 1000)
        )
