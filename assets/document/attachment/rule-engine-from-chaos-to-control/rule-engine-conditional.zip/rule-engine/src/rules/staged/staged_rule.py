from abc import ABC
from enum import Enum
from dataclasses import dataclass
from typing import List, Dict, Set

from src.rules.basic.rule import Rule, RuleResult


class ExecutionStage(Enum):
    """Define the stages of our data processing pipeline"""
    PREPROCESSING = "preprocessing"
    DATA_QUALITY = "data_quality"
    COMPLIANCE = "compliance"
    BUSINESS_RULES = "business_rules"
    POST_PROCESSING = "post_processing"


@dataclass
class StageConfig:
    """Configuration for a single execution stage"""
    stage: ExecutionStage
    enabled: bool = True
    fail_fast: bool = True  # Stop on first failure
    parallel_execution: bool = False
    timeout_seconds: int = 30
    retry_attempts: int = 0


class StagedRule(Rule, ABC):
    """Enhanced rule that belongs to specific execution stages"""

    def __init__(self, rule_id: str, stage: ExecutionStage,
                 dependencies: List[str] = None,
                 cross_stage_dependencies: List[str] = None):
        super().__init__(rule_id, dependencies or [])
        self.stage = stage
        self.cross_stage_dependencies = cross_stage_dependencies or []

    def can_execute_in_stage(self, stage: ExecutionStage,
                             completed_stages: Set[ExecutionStage],
                             stage_results: Dict[str, RuleResult]) -> bool:
        """Check if rule can execute in the given stage context"""
        # Must be the correct stage
        if self.stage != stage:
            return False

        # Check cross-stage dependencies
        for cross_dep in self.cross_stage_dependencies:
            if stage_results.get(cross_dep) != RuleResult.PASS:
                return False

        # Check same-stage dependencies
        return self.can_execute(stage_results)