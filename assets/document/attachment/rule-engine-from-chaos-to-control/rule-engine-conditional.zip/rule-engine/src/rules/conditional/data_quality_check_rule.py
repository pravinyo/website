import time

from src.rule_execution_result import RuleResult, RuleExecutionResult
from src.rules.conditional.conditional_rule import ConditionalRule


class DataQualityCheckRule(ConditionalRule):
    """Executes only if both positional and duplicate checks pass"""

    def __init__(self, rule_id: str = "data_quality_check"):
        super().__init__(
            rule_id,
            conditional_dependencies={
                "positional_check": RuleResult.PASS,
                "duplicate_check": RuleResult.PASS
            }
        )

    def execute(self, data: dict) -> RuleExecutionResult:
        start_time = time.time()

        # Simulate data quality validation
        required_fields = ["customer_id", "amount", "currency", "timestamp"]
        missing_fields = [field for field in required_fields if not data.get(field)]

        if missing_fields:
            return RuleExecutionResult(
                result=RuleResult.FAIL,
                message="Data quality check failed",
                failure_data={
                    "error": "missing_required_fields",
                    "missing_fields": missing_fields,
                    "required_fields": required_fields
                },
                execution_time_ms=int((time.time() - start_time) * 1000)
            )

        # Check data format
        amount = data.get("amount")
        if not isinstance(amount, (int, float)) or amount:
            start_time = time.time()

        # Simulate wire information validation
        wire_info = data.get("wire_info", {})

        required_wire_fields = ["routing_number", "account_number", "bank_name"]
        missing_wire_fields = [field for field in required_wire_fields
                               if not wire_info.get(field)]

        if missing_wire_fields:
            return RuleExecutionResult(
                result=RuleResult.FAIL,
                message="Wire information incomplete",
                failure_data={
                    "error": "incomplete_wire_info",
                    "missing_fields": missing_wire_fields,
                    "required_fields": required_wire_fields
                },
                execution_time_ms=int((time.time() - start_time) * 1000)
            )

        # Validate routing number format (simplified)
        routing_number = wire_info.get("routing_number", "")
        if len(routing_number) != 9 or not routing_number.isdigit():
            return RuleExecutionResult(
                result=RuleResult.FAIL,
                message="Invalid routing number format",
                failure_data={
                    "error": "invalid_routing_number",
                    "routing_number": routing_number,
                    "expected_format": "9-digit number"
                },
                execution_time_ms=int((time.time() - start_time) * 1000)
            )

        return RuleExecutionResult(
            result=RuleResult.PASS,
            message="Wire information validated",
            execution_time_ms=int((time.time() - start_time) * 1000)
        )