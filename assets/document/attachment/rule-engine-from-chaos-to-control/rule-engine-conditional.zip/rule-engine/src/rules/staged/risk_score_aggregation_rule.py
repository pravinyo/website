from typing import Dict

from src.rules.basic.rule import RuleResult
from src.rules.staged.staged_rule import StagedRule, ExecutionStage


class RiskScoreAggregationRule(StagedRule):
    """Post-processing rule that calculates composite risk scores"""

    def __init__(self, rule_id: str, scoring_model: str,
                 weight_factors: Dict[str, float]):
        super().__init__(rule_id, ExecutionStage.POST_PROCESSING)
        self.scoring_model = scoring_model
        self.weight_factors = weight_factors

    def execute(self, data: dict) -> RuleResult:
        risk_components = {}

        # Extract risk scores from previous rule executions
        if "credit_score" in data:
            # Convert credit score to risk score (higher credit = lower risk)
            risk_components["credit_score"] = max(0, (850 - data["credit_score"]) / 850)

        if "aml_risk_score" in data:
            risk_components["aml_risk"] = data["aml_risk_score"]

        if "geographic_risk_score" in data:
            risk_components["geographic_risk"] = data["geographic_risk_score"]

        if "identity_confidence_score" in data:
            # Convert confidence to risk (higher confidence = lower risk)
            risk_components["identity_confidence"] = 1.0 - data["identity_confidence_score"]

        # Calculate weighted composite score
        composite_score = 0.0
        total_weight = 0.0

        for component, score in risk_components.items():
            if component in self.weight_factors:
                weight = self.weight_factors[component]
                composite_score += score * weight
                total_weight += weight

        if total_weight > 0:
            final_risk_score = composite_score / total_weight
            data["composite_risk_score"] = final_risk_score

            # Determine risk category
            if final_risk_score < 0.3:
                data["risk_category"] = "low"
            elif final_risk_score < 0.7:
                data["risk_category"] = "medium"
            else:
                data["risk_category"] = "high"

            return RuleResult.PASS

        return RuleResult.FAIL
