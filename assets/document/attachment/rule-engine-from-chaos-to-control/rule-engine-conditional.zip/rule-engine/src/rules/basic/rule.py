from abc import ABC, abstractmethod
from enum import Enum


class RuleResult(Enum):
    PASS = "pass"
    FAIL = "fail"
    SKIP = "skip"  # For when dependencies aren't met


class Rule(ABC):
    """Enhanced rule with dependency support"""

    def __init__(self, rule_id: str, dependencies: list = None):
        self.rule_id = rule_id
        self.dependencies = dependencies or []

    @abstractmethod
    def execute(self, data: dict) -> RuleResult:
        pass

    def can_execute(self, completed_rules: dict) -> bool:
        """Check if all dependencies are satisfied"""
        for dep in self.dependencies:
            if completed_rules.get(dep) != RuleResult.PASS:
                return False
        return True
    