import time

from src.rule_execution_result import RuleResult, RuleExecutionResult
from src.rules.conditional.conditional_rule import ConditionalRule


class PositionalCheckRule(ConditionalRule):
    """Executes only if historical check passes"""

    def __init__(self, rule_id: str = "positional_check"):
        super().__init__(
            rule_id,
            conditional_dependencies={"historical_check": RuleResult.PASS}
        )

    def execute(self, data: dict) -> RuleExecutionResult:
        start_time = time.time()

        # Simulate positional validation
        position = data.get("position")
        if not position:
            return RuleExecutionResult(
                result=RuleResult.FAIL,
                message="Position data missing",
                failure_data={
                    "error": "missing_position_data",
                    "required_fields": ["latitude", "longitude", "timestamp"]
                },
                execution_time_ms=int((time.time() - start_time) * 1000)
            )

        # Check position validity
        lat = position.get("latitude", 0)
        lng = position.get("longitude", 0)

        if abs(lat) > 90 or abs(lng) > 180:
            return RuleExecutionResult(
                result=RuleResult.FAIL,
                message="Invalid position coordinates",
                failure_data={
                    "error": "invalid_coordinates",
                    "latitude": lat,
                    "longitude": lng,
                    "valid_ranges": {"latitude": "(-90, 90)", "longitude": "(-180, 180)"}
                },
                execution_time_ms=int((time.time() - start_time) * 1000)
            )

        return RuleExecutionResult(
            result=RuleResult.PASS,
            message="Positional check passed",
            execution_time_ms=int((time.time() - start_time) * 1000)
        )
