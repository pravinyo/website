from src.rules.basic.rule import Rule


class DataQualityRule(Rule):
    """Base class for data quality validation rules"""

    def __init__(self, rule_id: str, field_name: str, dependencies: list = None):
        super().__init__(rule_id, dependencies)
        self.field_name = field_name
        