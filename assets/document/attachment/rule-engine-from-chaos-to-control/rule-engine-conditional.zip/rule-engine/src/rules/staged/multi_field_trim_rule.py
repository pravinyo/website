from typing import List

from src.rules.basic.rule import RuleResult
from src.rules.staged.staged_rule import StagedRule, ExecutionStage


class MultiFieldTrimRule(StagedRule):
    """Preprocessing rule that trims whitespace from multiple fields"""

    def __init__(self, rule_id: str, fields: List[str], stage: ExecutionStage,
                 dependencies: List[str] = None,
                 cross_stage_dependencies: List[str] = None):
        super().__init__(rule_id, stage, dependencies, cross_stage_dependencies)
        self.fields = fields

    def execute(self, data: dict) -> RuleResult:
        modified = False
        for field in self.fields:
            if field in data and isinstance(data[field], str):
                original_value = data[field]
                trimmed_value = original_value.strip()
                if original_value != trimmed_value:
                    data[field] = trimmed_value
                    modified = True

        return RuleResult.PASS if modified else RuleResult.SKIP