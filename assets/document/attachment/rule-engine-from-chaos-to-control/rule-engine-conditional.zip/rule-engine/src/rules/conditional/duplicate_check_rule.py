import time

from src.rule_execution_result import RuleResult, RuleExecutionResult
from src.rules.conditional.conditional_rule import ConditionalRule


class DuplicateCheckRule(ConditionalRule):
    """Executes only if historical check passes"""

    def __init__(self, rule_id: str = "duplicate_check"):
        super().__init__(
            rule_id,
            conditional_dependencies={"historical_check": RuleResult.PASS}
        )

    def execute(self, data: dict) -> RuleExecutionResult:
        start_time = time.time()

        # Simulate duplicate detection
        transaction_id = data.get("transaction_id")
        existing_transactions = data.get("existing_transactions", [])

        if transaction_id in existing_transactions:
            return RuleExecutionResult(
                result=RuleResult.FAIL,
                message="Duplicate transaction detected",
                failure_data={
                    "error": "duplicate_transaction",
                    "transaction_id": transaction_id,
                    "existing_count": len(existing_transactions),
                    "duplicate_sources": [t for t in existing_transactions if t == transaction_id]
                },
                execution_time_ms=int((time.time() - start_time) * 1000)
            )

        return RuleExecutionResult(
            result=RuleResult.PASS,
            message="No duplicates found",
            execution_time_ms=int((time.time() - start_time) * 1000)
        )
