from typing import List, Dict

from src.rules.basic.rule import RuleResult
from src.rules.staged.staged_rule import StagedRule, ExecutionStage


class RequiredFieldsRule(StagedRule):
    """Data quality rule with detailed error reporting"""

    def __init__(self, rule_id: str, required_fields: List[str],
                 stage: ExecutionStage,
                 field_descriptions: Dict[str, str] = None,
                 dependencies: List[str] = None,
                 cross_stage_dependencies: List[str] = None):
        super().__init__(rule_id, stage, dependencies, cross_stage_dependencies)
        self.required_fields = required_fields
        self.field_descriptions = field_descriptions or {}

    def execute(self, data: dict) -> RuleResult:
        missing_fields = []

        for field in self.required_fields:
            value = data.get(field)
            if value is None or (isinstance(value, str) and not value.strip()):
                missing_fields.append(field)

        if missing_fields:
            # Store detailed error information for reporting
            error_details = {
                "missing_fields": missing_fields,
                "field_descriptions": {
                    field: self.field_descriptions.get(field, f"Field '{field}' is required")
                    for field in missing_fields
                }
            }
            # In a real implementation, you'd store this in the execution context
            return RuleResult.FAIL

        return RuleResult.PASS
