from abc import ABC, abstractmethod
from typing import List, Dict

from src.rule_execution_result import RuleResult, RuleExecutionResult


class ConditionalRule(ABC):
    """Base rule with conditional execution support"""

    def __init__(self, rule_id: str, dependencies: List[str] = None,
                 conditional_dependencies: Dict[str, RuleResult] = None):
        self.rule_id = rule_id
        self.dependencies = dependencies or []
        # Conditional dependencies: rule_id -> required_result
        self.conditional_dependencies = conditional_dependencies or {}

    @abstractmethod
    def execute(self, data: dict) -> RuleExecutionResult:
        """Execute the rule logic"""
        pass

    def can_execute(self, completed_rules: Dict[str, RuleExecutionResult]) -> bool:
        """Check if rule can execute based on dependencies and conditions"""
        # Check basic dependencies
        for dep in self.dependencies:
            if dep not in completed_rules:
                return False

        # Check conditional dependencies
        for rule_id, required_result in self.conditional_dependencies.items():
            if rule_id not in completed_rules:
                return False
            if completed_rules[rule_id].result != required_result:
                return False

        return True

    def should_skip(self, completed_rules: Dict[str, RuleExecutionResult]) -> tuple[bool, str]:
        """Determine if rule should be skipped with reason"""
        for rule_id, required_result in self.conditional_dependencies.items():
            if rule_id in completed_rules:
                actual_result = completed_rules[rule_id].result
                if actual_result != required_result:
                    return True, f"Skipped due to {rule_id} result: {actual_result.value}"
        return False, ""
