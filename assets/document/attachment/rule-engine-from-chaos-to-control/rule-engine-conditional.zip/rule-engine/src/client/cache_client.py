
class CacheClient:
    def setup(self) -> str:
        pass

class RedisClient(CacheClient):
    def setup(self) -> str:
        return "success"
