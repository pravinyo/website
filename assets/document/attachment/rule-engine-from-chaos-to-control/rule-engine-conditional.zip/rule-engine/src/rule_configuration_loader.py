from typing import Type, Any, Dict, List

from src.rules.staged.data_completeness_rule import DataCompletenessRule
from src.rules.staged.data_consistency_rule import DataConsistencyRule
from src.rules.staged.email_format_rule import EmailFormatRule
from src.rules.staged.kyc_compliance_rule import KYCComplianceRule
from src.rules.staged.kyc_identity_rule import KYCIdentityRule
from src.rules.staged.multi_field_trim_rule import MultiFieldTrimRule
from src.rules.staged.phone_format_rule import PhoneFormatRule
from src.rules.staged.required_field_rule import RequiredFieldsRule
from src.rules.staged.risk_score_aggregation_rule import RiskScoreAggregationRule
from src.rules.staged.staged_rule import StagedRule, ExecutionStage
from src.rules.staged.trim_whitspace_rule import TrimWhitespaceRule
from src.service_container import ServiceContainer


class RuleConfigurationLoader:
    """Loads rules from configuration and instantiates them with dependency injection"""

    def __init__(self, service_container: ServiceContainer):
        self.container = service_container
        self.rule_registry = {}  # rule_class_name -> Rule class
        self._register_built_in_rules()

    def _register_built_in_rules(self):
        """Register all available rule classes"""
        self.rule_registry.update({
            "TrimWhitespaceRule": TrimWhitespaceRule,
            "MultiFieldTrimRule": MultiFieldTrimRule,
            "RequiredFieldsRule": RequiredFieldsRule,
            "EmailFormatRule": EmailFormatRule,
            "PhoneFormatRule": PhoneFormatRule,
            "DataConsistencyRule": DataConsistencyRule,
            "KYCIdentityRule": KYCIdentityRule,
            "DataCompletenessRule": DataCompletenessRule,
            "KYCComplianceRule": KYCComplianceRule,
            "RiskScoreAggregationRule": RiskScoreAggregationRule
        })

    def register_rule_class(self, name: str, rule_class: Type[StagedRule]):
        """Register custom rule classes for dynamic loading"""
        self.rule_registry[name] = rule_class

    def load_rules_for_stage(self, stage: ExecutionStage,
                             config: Dict[str, Any]) -> List[StagedRule]:
        """Load all rules for a specific stage from configuration"""
        stage_name = stage.value

        if stage_name not in config["stages"]:
            return []

        stage_config = config["stages"][stage_name]

        if not stage_config.get("enabled", True):
            return []

        rules = []

        for rule_id, rule_config in stage_config["rules"].items():
            rule = self._create_rule_from_config(rule_id, rule_config, stage)
            if rule:
                rules.append(rule)

        return rules

    def _create_rule_from_config(self, rule_id: str,
                                 rule_config: Dict[str, Any],
                                 stage: ExecutionStage) -> StagedRule | None:
        """Create a rule instance from configuration"""
        rule_class_name = rule_config["class"]

        if rule_class_name not in self.rule_registry:
            raise ValueError(f"Unknown rule class: {rule_class_name}")

        rule_class = self.rule_registry[rule_class_name]
        params = rule_config.get("params", {})
        dependencies = rule_config.get("dependencies", [])
        cross_stage_deps = rule_config.get("cross_stage_dependencies", [])

        # Inject services into rule parameters
        resolved_params = self._resolve_service_dependencies(params)
        resolved_params.update({
            "rule_id": rule_id,
            "stage": stage,
            "dependencies": dependencies,
            "cross_stage_dependencies": cross_stage_deps
        })

        try:
            return rule_class(**resolved_params)
        except Exception as e:
            print(f"Failed to create rule {rule_id}: {e}")
            return None

    def _resolve_service_dependencies(self, params: Dict[str, Any]) -> Dict[str, Any]:
        """Resolve service dependencies in rule parameters"""
        resolved = {}

        for key, value in params.items():
            if isinstance(value, str) and value.startswith("service:"):
                # Format: "service:ServiceInterface:optional_name"
                service_parts = value.split(":")
                service_name = service_parts[1]
                optional_name = service_parts[2] if len(service_parts) > 2 else None

                # Dynamically resolve service interface
                service_interface = self.container.get_interface(service_name)
                if service_name:
                    resolved[key] = self.container.resolve(service_interface, optional_name)
                else:
                    raise ValueError(f"Unknown service interface: {service_name}")
            else:
                resolved[key] = value

        return resolved