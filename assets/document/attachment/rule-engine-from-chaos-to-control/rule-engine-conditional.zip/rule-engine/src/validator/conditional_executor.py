from typing import Dict, Any, List

from src.conditional_rule_executor import ConditionalRuleExecutor
from src.rule_execution_result import RuleResult
from src.rules.conditional.data_quality_check_rule import DataQualityCheckRule
from src.rules.conditional.duplicate_check_rule import DuplicateCheckRule
from src.rules.conditional.historical_check_rule import HistoricalCheckRule
from src.rules.conditional.positional_check_rule import PositionalCheckRule


class ConfigurableConditionalExecutor:
    """Configuration-driven conditional rule executor"""

    def __init__(self, config: Dict[str, Any]):
        self.config = config
        self.rule_registry = {
            "HistoricalCheckRule": HistoricalCheckRule,
            "PositionalCheckRule": PositionalCheckRule,
            "DuplicateCheckRule": DuplicateCheckRule,
            "DataQualityCheckRule": DataQualityCheckRule
        }
        self.rules = {}
        self._load_rules_from_config()

    def _load_rules_from_config(self):
        """Load rules from configuration"""
        for rule_id, rule_config in self.config["rules"].items():
            rule_class_name = rule_config["class"]
            if rule_class_name not in self.rule_registry:
                raise ValueError(f"Unknown rule class: {rule_class_name}")

            rule_class = self.rule_registry[rule_class_name]

            # Convert conditional dependencies
            conditional_deps = {}
            for dep_rule, dep_result in rule_config.get("conditional_dependencies", {}).items():
                conditional_deps[dep_rule] = RuleResult(dep_result.lower())

            # Create rule instance
            if rule_id == "historical_check":
                rule = rule_class()
            else:
                # Override the conditional dependencies from config
                rule = rule_class()
                rule.conditional_dependencies = conditional_deps

            self.rules[rule_id] = rule

    def execute_pipeline(self, data: Dict[str, Any]) -> Dict[str, Any]:
        """Execute the complete pipeline with conditional logic"""
        executor = ConditionalRuleExecutor()

        # Register all configured rules
        for rule_id, rule in self.rules.items():
            executor.register_rule(rule)

        # Execute all rules
        results = executor.execute_all(data)

        # Collect all failure data
        failure_data = {}
        for rule_id, result in results.items():
            if result.result == RuleResult.FAIL and result.failure_data:
                failure_data[rule_id] = result.failure_data

        return {
            "rule_results": {k: v.result.value for k, v in results.items()},
            "rule_messages": {k: v.message for k, v in results.items()},
            "failure_data": failure_data,
            "processed_data": data  # Data may be modified by rules
        }


class AdvancedConditionalExecutor:
    """Advanced executor with environment support and detailed reporting"""

    def __init__(self, environment: str = "production"):
        self.environment = environment
        self.configs = self._create_environment_configs()
        self.config = self.configs[environment]
        self.executor = ConfigurableConditionalExecutor(self.config)

    def _create_environment_configs(self):
        """Create different configurations for different environments"""

        # Development environment - skip expensive checks
        dev_config = {
            "version": "1.0.0-dev",
            "execution_settings": {
                "stop_on_failure": False,
                "collect_failure_data": True,
                "enable_conditional_execution": True
            },
            "rules": {
                "historical_check": {
                    "class": "HistoricalCheckRule",
                    "conditional_dependencies": {},
                    "enabled": True
                },
                "positional_check": {
                    "class": "PositionalCheckRule",
                    "conditional_dependencies": {"historical_check": "PASS"},
                    "enabled": True
                },
                "duplicate_check": {
                    "class": "DuplicateCheckRule",
                    "conditional_dependencies": {"historical_check": "PASS"},
                    "enabled": False  # Skip in dev
                },
                "data_quality_check": {
                    "class": "DataQualityCheckRule",
                    "conditional_dependencies": {"positional_check": "PASS"},  # Only needs positional in dev
                    "enabled": True
                },
            }
        }

        # Production environment - all checks enabled
        # prod_config = CONDITIONAL_PIPELINE_CONFIG.copy()

        return {"development": dev_config, "production": dev_config}

    def process_transaction(self, transaction_data: Dict[str, Any]) -> Dict[str, Any]:
        """Process a transaction through the conditional pipeline"""

        print(f"🏭 Processing transaction in {self.environment.upper()} environment")
        print(f"📋 Config version: {self.config['version']}")
        print()

        result = self.executor.execute_pipeline(transaction_data)

        # Add environment-specific processing
        # if self.environment == "production":
            # In production, log everything for audit
            # self._log_audit_trail(transaction_data, result)

        return {
            **result,
            "environment": self.environment,
            "recommendations": self._generate_recommendations(result)
        }

    def _log_audit_trail(self, data: Dict[str, Any], result: Dict[str, Any]):
        """Log audit trail for production"""
        print("📋 AUDIT TRAIL:")
        print(f"   Transaction ID: {data.get('transaction_id', 'Unknown')}")
        print(f"   Customer ID: {data.get('customer_id', 'Unknown')}")
        print(f"   Processing Result: {result['pipeline_result']}")
        print(f"   Rules Executed: {result['execution_summary']['total_rules']}")
        print(f"   Failures: {result['execution_summary']['failed']}")

        if result['failure_data']:
            print("   Failed Rules:")
            for rule_id in result['failure_data'].keys():
                print(f"     - {rule_id}")

    def _generate_recommendations(self, result: Dict[str, Any]) -> List[str]:
        """Generate recommendations based on execution results"""
        recommendations = []

        if result['pipeline_result'] == "success":
            recommendations.append("✅ Transaction approved - proceed with processing")
        else:
            # Analyze failures and provide specific recommendations
            failure_data = result['failure_data']

            if 'historical_check' in failure_data:
                recommendations.append("🔍 Review customer's historical transaction patterns")

            if 'positional_check' in failure_data:
                recommendations.append("📍 Verify transaction location and customer's typical locations")

            if 'duplicate_check' in failure_data:
                recommendations.append("🔄 Check for potential duplicate transactions")

            if 'data_quality_check' in failure_data:
                recommendations.append("📋 Request additional information from customer")

            if 'wire_info_check' in failure_data:
                recommendations.append("🏦 Verify banking information with customer")

        return recommendations