
class ApiClient:
    def call(self, request):
        pass


class HttpApiClient(ApiClient):
    def __init__(self):
        print("client init")

    def call(self, request) -> str:
        return "success"