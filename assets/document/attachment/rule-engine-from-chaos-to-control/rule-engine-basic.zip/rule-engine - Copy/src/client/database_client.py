
class DatabaseClient:
    def execute(self, query) -> str:
        pass


class ProductionDatabaseClient(DatabaseClient):
    def execute(self, query) -> str:
        return "success"