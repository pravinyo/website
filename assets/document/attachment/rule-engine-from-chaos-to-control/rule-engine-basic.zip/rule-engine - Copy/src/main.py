from datetime import datetime

from src.client.api_client import ApiClient, HttpApiClient
from src.client.cache_client import CacheClient, RedisClient
from src.client.database_client import DatabaseClient, ProductionDatabaseClient
from src.client.logger import Logger, ConsoleLogger, StructuredLogger, MetricsLogger
from src.rule_executor import RuleExecutor, ExecutionContext
from src.rules.email_format_rule import EmailFormatRule
from src.rules.enhanced_email_rule import EnhancedEmailRule
from src.rules.required_field_rule import RequiredFieldRule
from src.rules.rule import RuleResult
from src.service_container import ServiceContainer
from src.validator.address_validator import GeoCodingValidator, AddressValidator
from src.validator.email_validator import HybridEmailValidator, EmailValidator
from src.validator.phone_validator import PhoneValidator, TwilioPhoneValidator


def create_enterprise_rule_engine():
    """Configure a production-ready rule engine with full DI support"""

    container = ServiceContainer()

    # Register infrastructure dependencies
    container.register(DatabaseClient, ProductionDatabaseClient, singleton=True)
    container.register(ApiClient, HttpApiClient, singleton=True)
    container.register(CacheClient, RedisClient, singleton=True)

    # Register multiple logger implementations
    container.register(Logger, ConsoleLogger, name="console")
    container.register(Logger, StructuredLogger, name="structured")
    container.register(Logger, MetricsLogger, name="metrics")

    # Register validation service implementations
    container.register(EmailValidator, EnhancedEmailRule, singleton=True)
    container.register(AddressValidator, GeoCodingValidator, singleton=True)
    container.register(PhoneValidator, TwilioPhoneValidator, singleton=True)

    executor = RuleExecutor()

    # Register comprehensive business rules
    executor.register_rule(RequiredFieldRule("email_required", "email"))
    executor.register_rule(EmailFormatRule("email_format", "email"))
    executor.register_rule(RequiredFieldRule("age_required", "age"))
    executor.register_rule(GeoCodingValidator("address_validator"))
    executor.register_rule(HybridEmailValidator(container, "hybrid_email_validator"))

    return executor


def validate_customer_onboarding(customer_data: dict) -> dict:
    """Production customer onboarding validation"""

    executor = create_enterprise_rule_engine()

    context = ExecutionContext(
        data=customer_data,
        metadata={
            "validation_timestamp": datetime.now().isoformat(),
            "compliance_jurisdiction": "US",
            "risk_profile": "standard"
        },
        results={}
    )

    # Execute all validations
    results = executor.execute_all(context)

    # Generate comprehensive report
    return {
        "is_valid": all(r in [RuleResult.PASS, RuleResult.SKIP] for r in results.values()),
        "failed_rules": [rule_id for rule_id, result in results.items() if result == RuleResult.FAIL],
        "execution_summary": {
            "total_rules": len(results),
            "passed": sum(1 for r in results.values() if r == RuleResult.PASS),
            "failed": sum(1 for r in results.values() if r == RuleResult.FAIL),
            "skipped": sum(1 for r in results.values() if r == RuleResult.SKIP)
        },
        "metadata": context.metadata,
        "detailed_results": {k: v.value for k, v in results.items()}
    }

if __name__ == "__main__":
    validate_customer_onboarding({
        "email": "pravin.tripathi@dev",
        "age": 30
    })