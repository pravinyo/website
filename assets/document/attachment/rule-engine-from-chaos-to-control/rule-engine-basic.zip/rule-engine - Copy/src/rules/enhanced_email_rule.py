from src.client.logger import Logger
from src.validator.email_validator import EmailValidator
from src.rules.rule import Rule, RuleResult
from src.service_container import ServiceContainer


class EnhancedEmailRule(Rule):
    """Email rule with injected dependencies"""

    def __init__(self, rule_id: str, field_name: str, container: ServiceContainer):
        super().__init__(rule_id, dependencies=[f"required_{field_name}"])
        self.field_name = field_name

        # Dependencies injected at construction
        self.email_validator = container.resolve(EmailValidator)
        self.logger = container.resolve(Logger)

    def execute(self, data: dict) -> RuleResult:
        email = data.get(self.field_name)

        if not email:
            return RuleResult.SKIP

        is_valid = self.email_validator.is_valid(email)
        self.logger.log(f"Email validation for {email}: {'PASS' if is_valid else 'FAIL'}")

        return RuleResult.PASS if is_valid else RuleResult.FAIL