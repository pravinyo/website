from src.rules.data_quality_rule import DataQualityRule
from src.rules.rule import RuleResult


class NumericRangeRule(DataQualityRule):
    """Validates numeric values within business-defined ranges"""

    def __init__(self, rule_id: str, field_name: str, min_val: float, max_val: float):
        super().__init__(rule_id, field_name, dependencies=[f"required_{field_name}"])
        self.min_val = min_val
        self.max_val = max_val

    def execute(self, data: dict) -> RuleResult:
        value = data.get(self.field_name)

        if value is None:
            return RuleResult.SKIP

        try:
            numeric_value = float(value)
            if self.min_val <= numeric_value <= self.max_val:
                return RuleResult.PASS
        except (ValueError, TypeError):
            pass

        return RuleResult.FAIL
