from src.rules.rule import Rule, RuleResult


class EmailFormatRule(Rule):
    """Validates email format - depends on email being present"""

    def __init__(self, rule_id: str, field_name: str):
        # This rule depends on the required field check
        super().__init__(rule_id, dependencies=["email_required"])
        self.field_name = field_name

    def execute(self, data: dict) -> RuleResult:
        email = data.get(self.field_name)

        if email and '@' in email and '.' in email:
            return RuleResult.PASS

        return RuleResult.FAIL
