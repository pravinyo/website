from src.rules.rule import Rule, RuleResult


class CrossFieldValidationRule(Rule):
    """Validates relationships between multiple fields"""

    def __init__(self, rule_id: str, start_field: str, end_field: str):
        super().__init__(rule_id, dependencies=[
            f"required_{start_field}",
            f"required_{end_field}"
        ])
        self.start_field = start_field
        self.end_field = end_field

    def execute(self, data: dict) -> RuleResult:
        start_date = data.get(self.start_field)
        end_date = data.get(self.end_field)

        if start_date and end_date and start_date <= end_date:
            return RuleResult.PASS

        return RuleResult.FAIL
    