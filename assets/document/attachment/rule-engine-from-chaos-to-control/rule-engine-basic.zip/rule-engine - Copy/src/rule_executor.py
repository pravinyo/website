from dataclasses import dataclass
from typing import Dict, Any

from src.dependency_resolver import DependencyResolver
from src.rules.rule import RuleResult, Rule


@dataclass
class ExecutionContext:
    """Encapsulates all data needed during rule execution"""
    data: Dict[str, Any]  # Input data to validate
    metadata: Dict[str, Any]  # Additional context
    results: Dict[str, RuleResult]  # Rule execution results


class RuleExecutor:
    """Orchestrates rule execution with dependency resolution"""

    def __init__(self):
        self.rules = {}  # rule_id -> Rule object
        self.dependency_resolver = DependencyResolver()

    def register_rule(self, rule: Rule):
        """Register a rule for execution"""
        self.rules[rule.rule_id] = rule
        self.dependency_resolver.add_rule(rule)

    def execute_all(self, context: ExecutionContext) -> Dict[str, RuleResult]:
        """Execute all rules in dependency-resolved order"""
        execution_order = self.dependency_resolver.get_execution_order()

        for rule_id in execution_order:
            rule = self.rules[rule_id]

            if rule.can_execute(context.results):
                try:
                    result = rule.execute(context.data)
                    context.results[rule_id] = result
                    print(f"✓ {rule_id}: {result.value}")
                except Exception as e:
                    context.results[rule_id] = RuleResult.FAIL
                    print(f"✗ {rule_id}: Failed with error - {e}")
            else:
                context.results[rule_id] = RuleResult.SKIP
                print(f"↷ {rule_id}: Skipped (dependencies not met)")

        return context.results