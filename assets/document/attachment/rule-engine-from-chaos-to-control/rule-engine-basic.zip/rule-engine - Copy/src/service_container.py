from typing import Any
import inspect


class ServiceContainer:
    """Enterprise IoC container with constructor dependency injection"""

    def __init__(self):
        self._services = {}
        self._singletons = {}
        self._named_services = {}

    def register(self, interface: type, implementation: type, singleton: bool = False, name: str = None):
        """Register a service implementation with optional naming"""
        service_key = (interface, name) if name else interface

        self._services[service_key] = {
            'implementation': implementation,
            'singleton': singleton
        }

    def resolve(self, interface: type, name: str = None) -> Any:
        """Resolve a service dependency with automatic constructor injection"""
        service_key = (interface, name) if name else interface

        if service_key in self._singletons:
            return self._singletons[service_key]

        if service_key not in self._services:
            raise ValueError(f"Service {interface} (name: {name}) not registered")

        service_config = self._services[service_key]
        instance = self._create_instance_with_dependencies(service_config['implementation'])

        if service_config['singleton']:
            self._singletons[service_key] = instance

        return instance

    def _create_instance_with_dependencies(self, implementation_class: type) -> Any:
        """Create instance with automatic constructor dependency injection"""
        constructor = implementation_class.__init__
        signature = inspect.signature(constructor)

        parameters = [param for name, param in signature.parameters.items() if name != 'self']

        if not parameters:
            return implementation_class()

        dependencies = {}
        for param in parameters:
            param_type = param.annotation
            param_name = param.name

            try:
                dependencies[param_name] = self.resolve(param_type)
            except ValueError:
                if param.default != inspect.Parameter.empty:
                    dependencies[param_name] = param.default
                else:
                    raise ValueError(f"Cannot resolve dependency {param_type} for parameter {param_name}")

        return implementation_class(**dependencies)
