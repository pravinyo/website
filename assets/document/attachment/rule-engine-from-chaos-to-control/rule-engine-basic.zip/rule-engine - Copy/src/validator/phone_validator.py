from src.rules.rule import Rule


class PhoneValidator(Rule):
    def execute(self, data: dict) -> bool:
        pass


class TwilioPhoneValidator(PhoneValidator):
    def execute(self, data: dict) -> bool:
        return True
