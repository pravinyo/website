from abc import ABC

from src.rules.rule import Rule, RuleResult


class AddressValidator(Rule, ABC):
    def __init__(self, rule_id: str):
        super().__init__(rule_id)

    def validate(self, data: dict):
        pass


class GeoCodingValidator(AddressValidator):
    def __init__(self, rule_id: str):
        super().__init__(rule_id)

    def execute(self, data: dict) -> RuleResult:
        self.validate(data)
        return RuleResult.PASS

    def validate(self, data: dict):
        print("success")