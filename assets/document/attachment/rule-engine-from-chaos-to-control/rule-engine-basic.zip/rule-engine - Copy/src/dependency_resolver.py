from collections import defaultdict, deque

from src.rules.rule import Rule


class DependencyResolver:
    """Resolves rule execution order using topological sorting"""

    def __init__(self):
        self.graph = defaultdict(list)  # dependency -> [rules that depend on it]
        self.in_degree = defaultdict(int)  # rule -> number of dependencies

    def add_rule(self, rule: Rule):
        """Add rule to dependency graph"""
        if rule.rule_id not in self.in_degree:
            self.in_degree[rule.rule_id] = 0

        for dependency in rule.dependencies:
            self.graph[dependency].append(rule.rule_id)
            self.in_degree[rule.rule_id] += 1

    def get_execution_order(self) -> list:
        """
        Returns rules in topologically sorted order
        Uses Kahn's Algorithm - O(V + E) complexity
        """
        # Start with rules that have no dependencies
        queue = deque([
            rule_id for rule_id, degree in self.in_degree.items()
            if degree == 0
        ])

        execution_order = []

        while queue:
            current = queue.popleft()
            execution_order.append(current)

            # Update dependent rules
            for dependent in self.graph[current]:
                self.in_degree[dependent] -= 1
                if self.in_degree[dependent] == 0:
                    queue.append(dependent)

        # Detect circular dependencies
        if len(execution_order) != len(self.in_degree):
            raise ValueError("Circular dependency detected!")

        return execution_order