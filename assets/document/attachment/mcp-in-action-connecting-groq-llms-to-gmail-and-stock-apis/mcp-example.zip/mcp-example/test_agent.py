import asyncio
import os

from dotenv import load_dotenv
from groq import Groq

from ai_agent import Agent
from gateway.orchestrator import Orchestrator



async def create_agent_instance():
    api_key = os.getenv("GROQ_API_KEY")
    if not api_key:
        raise RuntimeError("Missing GROQ_API_KEY environment variable. Set it in .env or env.")
    client = Groq(api_key=api_key)
    mcp_orchestrator = await Orchestrator.create()
    return await Agent.create(client, mcp_orchestrator)


async def main():
    load_dotenv()
    agent = await create_agent_instance()
    try:
        print("=== Agent with Native Tool Support ===\n")

        # Test 1: Ask for emails
        # print("Query: Find all emails for invoice")
        # reply = await agent.talk("Find all emails for invoice")
        # print(f"Response: {reply}\n")

        # query = (
        #     "Hello! What are the stock price of TCS and Reliance? "
        #     "And how many units of each should I buy for total lump sum amount "
        #     "of 1 Lakh with 50% allocation each?"
        # )
        query = (
            "Hello! can you find email from last 3 days from sender no-reply@screener.in with subject containing Screener.in?"
        )
        print(f"Query: {query}")
        reply = await agent.talk(query)
        print(f"Response: {reply}\n")

    finally:
        await agent.close()


if __name__ == "__main__":
    asyncio.run(main())
