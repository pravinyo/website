import asyncio
from typing import Dict, Any

from gateway.clients import MCPClientRegistry


async def setup_mcp_clients() -> MCPClientRegistry:
    registry = MCPClientRegistry()
    await registry.register_stdio("proxy_email_server", "python", ["local_services/gmail_mcp_server.py"])
    await registry.register_http("remote_stock_server", "http://localhost:8000/mcp")
    return registry


class Orchestrator:
    def __init__(self, registry: MCPClientRegistry):
        self.registry: MCPClientRegistry = registry

    async def fetch_details(self, tool_name: str, args: Dict[str, Any]) -> Any:
        server_name, client = self.registry.get_client_for_tool(tool_name)
        return await client.call_tool(tool_name, args)

    def all_capabilities(self):
        return self.registry.capabilities

    @classmethod
    async def create(cls) -> "Orchestrator":
        registry = await setup_mcp_clients()
        return cls(registry)

    async def close(self):
        await self.registry.close_all()


async def main() -> None:
    orchestrator = await Orchestrator.create()
    print("Capabilities:")
    print(orchestrator.all_capabilities())
    try:
        print("\n list emails")
        tool_name = "list_filtered_messages"
        search_sender = "no-reply@screener.in"
        search_subject = "Screener.in"
        # Example time queries: 'after:2025/01/01', 'before:2025/11/01', 'newer_than:30d'
        search_time_period = "newer_than:90d"
        args = {
            "sender": search_sender,
            "subject_substring": search_subject,
            "time_query": search_time_period,
            "max_results": 25
        }
        result = await orchestrator.fetch_details(tool_name, args)
        print(result)
    finally:
        await orchestrator.close()


if __name__ == "__main__":
    asyncio.run(main())
