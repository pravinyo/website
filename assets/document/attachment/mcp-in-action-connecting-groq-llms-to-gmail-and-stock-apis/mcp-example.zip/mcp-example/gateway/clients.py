import asyncio
from typing import Dict, Any, List, Optional, Protocol, Tuple
from mcp import ClientSession
from mcp.client.stdio import stdio_client, StdioServerParameters
from fastmcp import Client


class MCPClient(Protocol):
    async def connect(self) -> None:
        ...

    async def call_tool(self, tool_name: str, tool_args: Dict[str, Any]) -> Any:
        ...

    async def list_tools(self) -> List[Dict[str, Any]]:
        ...

    async def close(self) -> None:
        ...


class StdioMCPClient:
    def __init__(self, command: str, args: List[str], server_alias: Optional[str] = None):
        self.server_params = StdioServerParameters(command=command, args=args)
        self._stdio_ctx = None
        self._session_ctx = None
        self._reader_writer = None
        self.session: Optional[ClientSession] = None
        self._server_alias = server_alias

    async def connect(self, retries: int = 3, backoff: float = 0.5) -> None:
        """Create stdio subprocess and initialize ClientSession. Retries on transient failures."""
        last_exc = None
        for attempt in range(1, retries + 1):
            try:
                # create and enter stdio context and keep the context object for later __aexit__
                self._stdio_ctx = stdio_client(self.server_params)
                self._reader_writer = await self._stdio_ctx.__aenter__()  # returns (reader, writer)
                reader, writer = self._reader_writer

                # create and enter ClientSession context and keep it for later teardown
                self._session_ctx = ClientSession(reader, writer)
                self.session = await self._session_ctx.__aenter__()
                await self.session.initialize()
                return
            except Exception as exc:
                last_exc = exc
                await self._cleanup_partial()
                if attempt < retries:
                    await asyncio.sleep(backoff * attempt)
                else:
                    raise RuntimeError(
                        f"Failed to start stdio MCP server after {retries} attempts"
                    ) from last_exc

    async def _cleanup_partial(self) -> None:
        """Teardown any partially created contexts safely."""
        # Close session if opened
        if self.session is not None and self._session_ctx is not None:
            try:
                await self._session_ctx.__aexit__(None, None, None)
            except Exception:
                pass
            self.session = None
            self._session_ctx = None

        # Close stdio context if opened
        if self._stdio_ctx is not None:
            try:
                await self._stdio_ctx.__aexit__(None, None, None)
            except Exception:
                pass
            self._stdio_ctx = None
            self._reader_writer = None

    async def call_tool(self, tool_name: str, tool_args: Dict[str, Any]) -> Any:
        if not self.session:
            raise RuntimeError("StdioMCPClient not connected")
        return await self.session.call_tool(tool_name, tool_args)

    async def list_tools(self) -> List[Dict[str, Any]]:
        if not self.session:
            raise RuntimeError("StdioMCPClient not connected")
        result = await self.session.list_tools()
        return result.tools

    async def close(self) -> None:
        await self._cleanup_partial()


class HTTPMCPClient:
    def __init__(self, base_url: str):
        # e.g. "http://localhost:8000/mcp"
        self.base_url = base_url.rstrip("/")
        self._client = Client(self.base_url)  # FastMCP infers HTTP transport[attached_file:1]
        self._entered = False

    async def connect(self) -> None:
        """
        Open connection and initialize MCP.
        Kept for API parity with your old implementation.
        """
        if self._entered:
            return
        await self._client.__aenter__()  # enters async context[attached_file:1]
        self._entered = True

    async def call_tool(self, tool_name: str, tool_args: Dict[str, Any]) -> Any:
        """
        Call a tool by name.
        In your old version `tool_name` was the raw JSON‑RPC method;
        here it is the MCP tool name (e.g. "get_latest_price").
        """
        if not self._entered:
            await self.connect()

        # fastmcp.Client.call_tool returns a ToolResult‑like object[attached_file:1]
        result = await self._client.call_tool(tool_name, tool_args)
        # Normalize to the payload you actually care about
        return getattr(result, "data", result)

    async def list_tools(self) -> List[Dict[str, Any]]:
        """
        List available tools on the server.
        Returns list[dict] to match your previous .get("tools", []) style.
        """
        if not self._entered:
            await self.connect()

        tools = await self._client.list_tools()
        # Tool descriptors are Pydantic models; convert to plain dicts
        return [t.model_dump() for t in tools]

    async def close(self) -> None:
        if not self._entered:
            return
        await self._client.__aexit__(None, None, None)
        self._entered = False


class MCPClientRegistry:
    def __init__(self):
        self.clients: Dict[str, MCPClient] = {}
        self.tools_server_map: Dict[str, str] = {}
        self.capabilities = []

    async def register_stdio(self, alias: str, command: str, args: List[str]) -> None:
        client = StdioMCPClient(command, args, server_alias=alias)
        await client.connect()
        tools = await client.list_tools()
        for tool in tools:
            self.tools_server_map[tool.name] = alias
        self.clients[alias] = client
        self.capabilities.extend(tools)

    async def register_http(self, alias: str, base_url: str) -> None:
        client = HTTPMCPClient(base_url)
        await client.connect()
        tools = await client.list_tools()
        for tool in tools:
            self.tools_server_map[tool["name"]] = alias
        self.clients[alias] = client
        self.capabilities.extend(tools)

    def get_client_for_tool(self, tool_name: str) -> Tuple[str, MCPClient]:
        server_name = self.tools_server_map.get(tool_name)
        if not server_name:
            raise KeyError(f"No server registered for tool: {tool_name}")
        client = self.clients.get(server_name)
        if not client:
            raise KeyError(f"No client instance found for server: {server_name}")
        return server_name, client

    def get_all_capabilities(self) -> list[Dict[str, Any]]:
        return self.capabilities

    async def close_all(self) -> None:
        for client in list(self.clients.values()):
            try:
                await client.close()
            except Exception:
                pass
        self.clients.clear()
        self.tools_server_map.clear()
