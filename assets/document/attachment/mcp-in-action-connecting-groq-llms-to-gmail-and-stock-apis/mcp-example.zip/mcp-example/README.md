# MCP Example Setup Instructions

## Environment Configuration

### .env File
To configure your environment variables, create a `.env` file in the root directory with the following values:

```
GROQ_API_KEY=your_api_key_here
```

Replace `your_api_key_here` with your actual GROQ API key.

## Gmail API Credentials
To interact with the Gmail API, you need to set up OAuth 2.0 credentials. Follow these steps to create the necessary files:

### credentials.json
1. Go to Google Cloud Console → APIs & Services → Credentials
2. Find your OAuth 2.0 Client ID and click the download icon
3. Save the file as `credentials.json` in your project root
4. Keep this file secure and do not commit it to version control

### token.json
This file is generated automatically on first authentication:
1. Run your application for the first time
2. You'll be prompted to authenticate with Gmail
3. Grant the necessary permissions
4. A `token.json` file will be created automatically in your project root
5. This file stores your refresh token for future requests

**Note:** Add both `credentials.json` and `token.json` to `.gitignore` to prevent accidental exposure of sensitive data.

## Steps to add new MCP server
1. Open [`orchestrator.py`](./orchestrator.py) file
2. Add the new MCP server details in the `setup_mcp_clients` function located in the [`orchestrator.py`](./orchestrator.py) file.
3. Save the file and restart the application
4. Verify that the new MCP server is functioning correctly by checking the logs or using the application interface.