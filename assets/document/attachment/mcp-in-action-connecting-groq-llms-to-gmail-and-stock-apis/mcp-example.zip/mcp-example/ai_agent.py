import asyncio
import json
from typing import List, Dict, Any

from groq import Groq

from gateway.orchestrator import Orchestrator


SYSTEM_PROTOCOL = (
    "You are a helpful assistant. "
    "Use the provided tools to answer questions about stock prices, emails, and other data. "
    "When a tool is needed, call it directly. Otherwise, answer using your knowledge."
)


class Agent:
    def __init__(
            self,
            _client: Groq,
            mcp_orchestrator: Orchestrator,
            system_messages: List[Dict[str, str]],
            tools: List[Dict[str, Any]],
    ):
        self.client = _client
        self.mcp_orchestrator = mcp_orchestrator
        self.conversation_history = system_messages
        self.tools = tools

    @classmethod
    async def create(cls, _client: Groq, mcp_orchestrator: Orchestrator) -> "Agent":
        """Factory to build Agent with MCP tools as Groq tool definitions."""
        system_messages = [
            {"role": "system", "content": SYSTEM_PROTOCOL},
        ]

        # Build tool definitions from orchestrator's registry
        tools = cls._build_groq_tools(mcp_orchestrator)

        return cls(_client, mcp_orchestrator, system_messages, tools)

    @classmethod
    def _build_groq_tools(cls, mcp_orchestrator: Orchestrator) -> List[Dict[str, Any]]:
        """Convert MCP tools to Groq tool format."""
        tools = []
        for capability in mcp_orchestrator.all_capabilities():
            tool = dict(capability)
            tool_def = {
                "type": "function",
                "function": {
                    "name": tool["name"],
                    "description": tool["description"],
                    "parameters": tool["inputSchema"],
                },
            }
            tools.append(tool_def)
        return tools

    @classmethod
    def _to_serializable(cls, obj):
        """Recursively convert objects to JSON-serializable primitives."""
        if obj is None:
            return None
        if isinstance(obj, (str, int, float, bool)):
            return obj
        if isinstance(obj, dict):
            return {k: cls._to_serializable(v) for k, v in obj.items()}
        if isinstance(obj, (list, tuple, set)):
            return [cls._to_serializable(i) for i in obj]
        if hasattr(obj, "content") and not isinstance(obj.content, (str, bytes)):
            return {
                "meta": cls._to_serializable(getattr(obj, "meta", None)),
                "content": cls._to_serializable(getattr(obj, "content", None)),
                "structuredContent": cls._to_serializable(getattr(obj, "structuredContent", None)),
                "isError": cls._to_serializable(getattr(obj, "isError", None)),
            }
        if hasattr(obj, "text") and hasattr(obj, "type"):
            return {"type": getattr(obj, "type", None), "text": getattr(obj, "text", None)}
        if hasattr(obj, "__dict__"):
            return {k: cls._to_serializable(v) for k, v in vars(obj).items() if not k.startswith("_")}
        return str(obj)

    async def get_groq_response(self) -> str:
        """Call Groq with tool definitions and handle tool_calls iteratively."""
        def _call():
            return self.client.chat.completions.create(
                model="openai/gpt-oss-120b",
                messages=self.conversation_history,
                tools=self.tools,
                tool_choice="auto",  # Let model decide when to call tools
                temperature=0.7,
                max_completion_tokens=1024,
            )

        # Loop until model returns text (no tool calls)
        while True:
            # Call the model
            completion = await asyncio.to_thread(_call)
            response_message = completion.choices[0].message

            # If no tool calls, return the text response
            if not response_message.tool_calls:
                return response_message.content or ""

            # Append assistant's response (may contain text + tool calls)
            self.conversation_history.append({
                "role": "assistant",
                "content": response_message.content or ""
            })

            # Execute each tool call and collect results
            tool_results = []
            for tool_call in response_message.tool_calls:
                tool_name = tool_call.function.name
                try:
                    tool_args = json.loads(tool_call.function.arguments)
                except Exception:
                    tool_args = tool_call.function.arguments or {}

                # Call the tool via orchestrator
                try:
                    tool_result = await self.mcp_orchestrator.fetch_details(tool_name, tool_args)
                except Exception as ex:
                    tool_result = {"error": str(ex)}

                # Serialize result
                serializable_result = Agent._to_serializable(tool_result)
                tool_results.append({
                    "tool_use_id": tool_call.id,
                    "parameter": tool_args,
                    "content": json.dumps(serializable_result),
                })

            # Append tool results to conversation so model can see them
            for tr in tool_results:
                self.conversation_history.append({
                    "role": "user",
                    "content": f"Tool result from {tr['tool_use_id']} with parameter {tr['parameter']}:\n{tr['content']}"
                })

            # Loop back: model will be called again with tool results in context
            # If model has follow-up tool calls, they will be handled
            # If model returns text answer, loop exits and returns it

    async def talk(self, prompt: str) -> str:
        """Send a user message and get a response."""
        self.conversation_history.append({"role": "user", "content": prompt})
        response = await self.get_groq_response()
        self.conversation_history.append({"role": "assistant", "content": response})
        return response

    async def close(self) -> None:
        """Close the orchestrator."""
        await self.mcp_orchestrator.close()