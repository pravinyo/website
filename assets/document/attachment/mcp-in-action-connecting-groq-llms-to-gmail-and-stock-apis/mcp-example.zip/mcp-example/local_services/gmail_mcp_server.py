import os
from datetime import date
from typing import List, Dict

from mcp.server.fastmcp import FastMCP
from google.auth.transport.requests import Request
from google.auth.exceptions import RefreshError
from google.oauth2.credentials import Credentials
from google_auth_oauthlib.flow import InstalledAppFlow
from googleapiclient.discovery import build
from googleapiclient.errors import HttpError
import base64

mcp = FastMCP("gmail_mcp_server")

# Gmail API scopes
SCOPES = ['https://www.googleapis.com/auth/gmail.readonly']

# Global service instance
gmail_service = None
token_path = "token.json"
credential_path = "credentials.json"


def get_gmail_service():
    """Initialize and return Gmail API service with automatic token recovery."""
    global gmail_service
    if gmail_service:
        return gmail_service

    creds = None

    # Try loading existing token; if it's corrupt remove it so we re-auth
    try:
        if os.path.exists(token_path):
            creds = Credentials.from_authorized_user_file(token_path, SCOPES)
    except Exception:
        try:
            os.remove(token_path)
        except Exception:
            pass
        creds = None

    # If no valid creds, try refresh; if refresh fails (revoked/expired) remove token and re-auth
    if not creds or not creds.valid:
        if creds and creds.expired and creds.refresh_token:
            try:
                creds.refresh(Request())
            except RefreshError:
                # token revoked or expired server-side -> delete token and force re-auth
                try:
                    os.remove(token_path)
                except Exception:
                    pass
                creds = None
        if not creds:
            flow = InstalledAppFlow.from_client_secrets_file(credential_path, SCOPES)
            creds = flow.run_local_server(port=0)
            with open(token_path, 'w') as token:
                token.write(creds.to_json())

    try:
        gmail_service = build('gmail', 'v1', credentials=creds)
        return gmail_service
    except HttpError as error:
        raise Exception(f'An error occurred: {error}')


def get_header_value(headers, name):
    """Utility to extract a specific header value."""
    for header in headers:
        if header['name'].lower() == name.lower():
            return header['value']
    return None


@mcp.tool(
    description="List Gmail messages with attachments"
)
def list_messages_with_attachments(max_results: int = 10):
    """Lists messages with attachments, extracts subject, sender, and attachment info."""
    try:
        service = get_gmail_service()
        response = service.users().messages().list(
            userId='me',
            maxResults=max_results,
            q="has:attachment"
        ).execute()

        messages = response.get('messages', [])
        email_data_list = []

        for msg_id_dict in messages:
            msg_id = msg_id_dict['id']
            message = service.users().messages().get(
                userId='me',
                id=msg_id,
                format='full'
            ).execute()

            payload = message.get('payload', {})
            headers = payload.get('headers', [])

            subject = get_header_value(headers, 'Subject')
            sender = get_header_value(headers, 'From')

            attachments_info = []
            parts = payload.get('parts', [])

            def get_attachment_parts(parts):
                for part in parts:
                    if part.get('filename') and part.get('body') and part.get('body').get('attachmentId'):
                        attachments_info.append({
                            'filename': part['filename'],
                            'attachmentId': part['body']['attachmentId']
                        })
                    if part.get('parts'):
                        get_attachment_parts(part['parts'])

            get_attachment_parts(parts)

            email_data_list.append({
                'id': msg_id,
                'subject': subject,
                'sender': sender,
                'attachments': attachments_info
            })

        return email_data_list

    except HttpError as error:
        return {"error": f'An HTTP error occurred: {error}'}


@mcp.tool(description=(
    "Lists filtered mail messages with optional sender, subject, and time filters."
    "Example time queries: 'after:2025/01/01', 'before:2025/11/01', 'newer_than:30d'"
))
def list_filtered_messages(
        sender: str = None,
        subject_substring: str = None,
        time_query: str = None,
        max_results: int = 10
) -> List[Dict[str, str]]:
    try:
        service = get_gmail_service()
        query_parts = []

        if sender:
            query_parts.append(f'from:"{sender}"')

        if subject_substring:
            query_parts.append(f'subject:"{subject_substring}"')

        if time_query:
            query_parts.append(time_query)

        final_query = " ".join(query_parts) if query_parts else ""

        response = service.users().messages().list(
            userId='me',
            maxResults=max_results,
            q=final_query
        ).execute()

        messages = response.get('messages', [])
        email_data_list = []

        for msg_id_dict in messages:
            msg_id = msg_id_dict['id']
            message = service.users().messages().get(
                userId='me',
                id=msg_id,
                format='full'
            ).execute()

            payload = message.get('payload', {})
            headers = payload.get('headers', [])

            subject = get_header_value(headers, 'Subject')
            sender_info = get_header_value(headers, 'From')

            attachments_info = []
            parts = payload.get('parts', [])

            def get_attachment_parts(parts):
                for part in parts:
                    if part.get('filename') and part.get('body') and part.get('body').get('attachmentId'):
                        attachments_info.append({
                            'filename': part['filename'],
                            'attachmentId': part['body']['attachmentId']
                        })
                    if part.get('parts'):
                        get_attachment_parts(part['parts'])

            get_attachment_parts(parts)

            body_text = ""
            if 'parts' in payload:
                for part in payload['parts']:
                    if part['mimeType'] == 'text/plain':
                        data = part['body'].get('data', '')
                        if data:
                            body_text = base64.urlsafe_b64decode(data).decode('utf-8')
                            break
            else:
                data = payload['body'].get('data', '')
                if data:
                    body_text = base64.urlsafe_b64decode(data).decode('utf-8')

            email_data_list.append({
                'id': msg_id,
                'subject': subject,
                'sender': sender_info,
                'body': body_text,
                'attachments': attachments_info
            })

        return email_data_list

    except HttpError as error:
        return {"error": f'An HTTP error occurred: {error}'}


@mcp.tool(
    description="Download a message attachment and save to mail_attachments/YYYY-MM-DD/<filename>. "
                "Requires message_id, attachment_id and filename."
)
def download_attachment(message_id: str, attachment_id: str, filename: str, user_id: str = "me", base_dir: str = "mail_attachments"):
    """
    Download an attachment from a Gmail message and save it locally in a date-organized folder.

    Minimum required params:
      - message_id: Gmail message ID (from list_filtered_messages or list_messages_with_attachments)
      - attachment_id: attachmentId from the message part body
      - filename: the original filename to save as (will be basename-sanitized)

    Optional:
      - user_id: Gmail user, defaults to 'me'
      - base_dir: base directory to save attachments (defaults to 'mail_attachments')

    Returns: dict with saved_path on success or error message.
    """
    try:
        service = get_gmail_service()

        att = service.users().messages().attachments().get(
            userId=user_id,
            messageId=message_id,
            id=attachment_id
        ).execute()

        data = att.get('data')
        if not data:
            return {"error": "No attachment data returned from Gmail API."}

        file_bytes = base64.urlsafe_b64decode(data.encode('utf-8'))

        # sanitize filename
        safe_name = os.path.basename(filename)

        date_folder = date.today().isoformat()
        save_dir = os.path.join(base_dir, date_folder)
        os.makedirs(save_dir, exist_ok=True)

        save_path = os.path.join(save_dir, safe_name)

        # If file exists, avoid overwrite by appending a counter
        if os.path.exists(save_path):
            base, ext = os.path.splitext(safe_name)
            counter = 1
            while True:
                candidate = f"{base}_{counter}{ext}"
                candidate_path = os.path.join(save_dir, candidate)
                if not os.path.exists(candidate_path):
                    save_path = candidate_path
                    break
                counter += 1

        with open(save_path, "wb") as f:
            f.write(file_bytes)

        return {"saved_path": os.path.abspath(save_path)}

    except HttpError as error:
        return {"error": f'An HTTP error occurred: {error}'}
    except Exception as e:
        return {"error": str(e)}

if __name__ == "__main__":
    # # --- DEFINE YOUR SEARCH CRITERIA HERE ---
    # search_sender = "no-reply@screener.in"
    # search_subject = "Screener.in"
    # # Example time queries: 'after:2025/01/01', 'before:2025/11/01', 'newer_than:30d'
    # search_time_period = "newer_than:90d"
    # # ----------------------------------------
    #
    # emails = list_filtered_messages(
    #     sender=search_sender,
    #     subject_substring=search_subject,
    #     time_query=search_time_period,
    #     max_results=25  # Increase the max number of results to retrieve
    # )
    # print(emails)
    mcp.run(transport="stdio")
