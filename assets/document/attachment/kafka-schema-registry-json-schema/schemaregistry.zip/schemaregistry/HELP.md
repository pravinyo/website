
1. Delete schema
```text
curl --request DELETE \
  --url http://localhost:8081/subjects/user-registration-test-value
```

2. fetch schema
```text
curl --request GET \
--url http://localhost:8081/subjects/user-registration-test-value/versions/latest
```

3. Post schema
```text
curl --request POST \
  --url http://localhost:8081/subjects/user-registration-test-value/versions \
  --header 'Content-Type: application/vnd.schemaregistry.v1+json' \
  --data '{
	"schemaType": "JSON",
	"schema": "{ \"$schema\": \"http://json-schema.org/draft-07/schema#\", \"title\": \"User\", \"description\": \"Schema representing a user\", \"type\": \"object\", \"additionalProperties\": false, \"properties\": { \"name\": { \"type\": \"string\", \"description\": \"Name of person.\" }, \"email\": { \"type\": \"string\", \"description\": \"email of person.\" }, \"userId\": { \"type\": \"string\", \"description\": \"user id in the system\" } }, \"required\": [\"name\", \"userId\", \"email\"] }"
}'
```

4. delete topic
```text
curl --request DELETE \
  --url 'http://localhost:8100/kafka/topic?topicName=user_registration_topic' \
  --header 'User-Agent: insomnia/10.2.0'
```

5. push message
```text
curl --request POST \
  --url http://localhost:8100/kafka/publish \
  --header 'Content-Type: application/json' \
  --header 'User-Agent: insomnia/10.2.0' \
  --data '{
	"userId": "pravin",
	"email": "pravin@pravin.dev"
}'
```