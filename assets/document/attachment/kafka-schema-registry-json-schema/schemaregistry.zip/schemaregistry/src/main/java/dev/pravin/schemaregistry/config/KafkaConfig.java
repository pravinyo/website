package dev.pravin.schemaregistry.config;

import dev.pravin.schemaregistry.model.UserRegistrationTest;
import io.confluent.kafka.schemaregistry.client.CachedSchemaRegistryClient;
import io.confluent.kafka.schemaregistry.client.SchemaRegistryClient;
import io.confluent.kafka.schemaregistry.client.rest.exceptions.RestClientException;
import io.confluent.kafka.schemaregistry.json.JsonSchema;
import io.confluent.kafka.serializers.json.KafkaJsonSchemaDeserializer;
import org.apache.kafka.clients.admin.AdminClient;
import org.apache.kafka.clients.admin.AdminClientConfig;
import org.apache.kafka.clients.producer.ProducerConfig;
import org.apache.kafka.clients.consumer.ConsumerConfig;
import org.apache.kafka.common.serialization.StringDeserializer;
import org.apache.kafka.common.serialization.StringSerializer;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.kafka.annotation.EnableKafka;
import org.springframework.kafka.config.ConcurrentKafkaListenerContainerFactory;
import org.springframework.kafka.core.*;
import io.confluent.kafka.serializers.json.KafkaJsonSchemaSerializer;

import java.io.IOException;
import java.util.HashMap;
import java.util.Map;
import java.util.Properties;

@EnableKafka
@Configuration
public class KafkaConfig {

    public static final String BROKER_URL = "localhost:19092";
    public static final String SCHEMA_REGISTRY_URL = "http://localhost:8081";
    public static final String SPRING_KAFKA_ADMIN_CLIENT = "spring-kafka-admin-client";
    public static final String GROUP_ID = "group_id_23";

    @Bean
    public ProducerFactory<String, UserRegistrationTest> producerFactory() {
        Map<String, Object> config = new HashMap<>();
        config.put(ProducerConfig.BOOTSTRAP_SERVERS_CONFIG, BROKER_URL);
        config.put(ProducerConfig.KEY_SERIALIZER_CLASS_CONFIG, StringSerializer.class);
        config.put(ProducerConfig.VALUE_SERIALIZER_CLASS_CONFIG, KafkaJsonSchemaSerializer.class);
        config.put("schema.registry.url", SCHEMA_REGISTRY_URL);
        return new DefaultKafkaProducerFactory<>(config);
    }

    @Bean
    public KafkaTemplate<String, UserRegistrationTest> kafkaTemplate() {
        return new KafkaTemplate<>(producerFactory());
    }

    @Bean
    public SchemaRegistryClient schemaRegistryClient() throws RestClientException, IOException {
        CachedSchemaRegistryClient client = new CachedSchemaRegistryClient(SCHEMA_REGISTRY_URL, 1);
        String jsonString = """
                {
                  "$schema": "http://json-schema.org/draft-07/schema#",
                  "title": "User",
                  "description": "Schema representing a user",
                  "type": "object",
                  "additionalProperties": false,
                  "properties": {
                    "name": {
                      "type": "string",
                      "description": "Name of person."
                    },
                    "email": {
                      "type": "string",
                      "description": "email of person."
                    },
                    "userId": {
                      "type": "string",
                      "description": "user id in the system"
                    }
                  },
                  "required": ["name", "userId", "email"]
                }
                """;
        client.register("user-registration-test-value", new JsonSchema(jsonString));
        return client;
    }

    @Bean
    public ConsumerFactory<String, UserRegistrationTest> consumerFactory(SchemaRegistryClient schemaRegistryClient) {
        Map<String, Object> config = new HashMap<>();
        config.put(ConsumerConfig.BOOTSTRAP_SERVERS_CONFIG, BROKER_URL);
        config.put(ConsumerConfig.GROUP_ID_CONFIG, GROUP_ID);
        config.put(ConsumerConfig.KEY_DESERIALIZER_CLASS_CONFIG, StringDeserializer.class);
        config.put(ConsumerConfig.VALUE_DESERIALIZER_CLASS_CONFIG, KafkaJsonSchemaDeserializer.class);
        config.put("schema.registry.url", SCHEMA_REGISTRY_URL);
        config.put("specific.json.reader", true);
        return new DefaultKafkaConsumerFactory<>(config, new StringDeserializer(),
                new KafkaJsonSchemaDeserializer<>(schemaRegistryClient));
    }

    @Bean
    public ConcurrentKafkaListenerContainerFactory<String, UserRegistrationTest> kafkaListenerContainerFactory(SchemaRegistryClient schemaRegistryClient) {
        ConcurrentKafkaListenerContainerFactory<String, UserRegistrationTest> factory = new ConcurrentKafkaListenerContainerFactory<>();
        factory.setConsumerFactory(consumerFactory(schemaRegistryClient));
        return factory;
    }

    @Bean
    public AdminClient adminClient() {
        Properties properties = new Properties();
        properties.put(AdminClientConfig.BOOTSTRAP_SERVERS_CONFIG, BROKER_URL);
        properties.put(AdminClientConfig.CLIENT_ID_CONFIG, SPRING_KAFKA_ADMIN_CLIENT);
        return AdminClient.create(properties);
    }
}