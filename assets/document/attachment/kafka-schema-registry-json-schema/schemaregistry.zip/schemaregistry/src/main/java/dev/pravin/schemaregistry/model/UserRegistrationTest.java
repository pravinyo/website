package dev.pravin.schemaregistry.model;

import lombok.Builder;
import lombok.Data;
import lombok.Getter;

@Data
@Builder
@Getter
public class UserRegistrationTest {
    private String userId;
    private String email;
    private String name;
}
