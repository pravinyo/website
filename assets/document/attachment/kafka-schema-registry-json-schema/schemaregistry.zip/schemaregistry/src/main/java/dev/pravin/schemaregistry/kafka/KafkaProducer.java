package dev.pravin.schemaregistry.kafka;

import dev.pravin.schemaregistry.model.UserRegistrationTest;
import io.confluent.kafka.schemaregistry.client.SchemaRegistryClient;
import io.confluent.kafka.schemaregistry.client.rest.exceptions.RestClientException;
import lombok.RequiredArgsConstructor;
import org.springframework.kafka.core.KafkaTemplate;
import org.springframework.stereotype.Service;

import java.io.IOException;

import static dev.pravin.schemaregistry.kafka.Constant.TOPIC;

@Service
@RequiredArgsConstructor
public class KafkaProducer {
    private final SchemaRegistryClient schemaRegistryClient;
    private final KafkaTemplate<String, UserRegistrationTest> kafkaTemplate;

    public void sendMessage(UserRegistrationTest userRegistrationTest) throws RestClientException, IOException {
        schemaRegistryClient.reset();
        int version = schemaRegistryClient.getLatestSchemaMetadata(TOPIC+"-value").getVersion();
        System.out.println("Version: " + version);
        kafkaTemplate.send(TOPIC, userRegistrationTest);
        System.out.println("Message sent: " + userRegistrationTest);
    }
}
