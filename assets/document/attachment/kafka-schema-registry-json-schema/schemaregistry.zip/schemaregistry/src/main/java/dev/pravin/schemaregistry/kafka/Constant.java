package dev.pravin.schemaregistry.kafka;

public class Constant {
    public static final String TOPIC = "user-registration-test";
}
