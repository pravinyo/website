package dev.pravin.schemaregistry.service;

import lombok.RequiredArgsConstructor;
import org.apache.kafka.clients.admin.AdminClient;
import org.apache.kafka.clients.admin.DeleteTopicsResult;
import org.apache.kafka.common.KafkaFuture;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.Collections;
import java.util.concurrent.ExecutionException;

@Service
@RequiredArgsConstructor
public class KafkaTopicService {
    private final AdminClient adminClient;

    public String deleteTopic(String topicName) throws InterruptedException, ExecutionException {
        DeleteTopicsResult deleteTopicsResult = adminClient.deleteTopics(Collections.singletonList(topicName));
        KafkaFuture<Void> future = deleteTopicsResult.topicNameValues().get(topicName);
        future.get();
        return "Topic " + topicName + " deleted successfully.";
    }
}
