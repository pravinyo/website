package dev.pravin.schemaregistry.kafka;

import lombok.RequiredArgsConstructor;
import org.springframework.kafka.annotation.KafkaListener;
import org.springframework.stereotype.Service;

import static dev.pravin.schemaregistry.kafka.Constant.TOPIC;

@Service
@RequiredArgsConstructor
public class KafkaConsumer {

    String schema = "{ \"$schema\": \"http://json-schema.org/draft-07/schema#\", \"title\": \"User\", \"description\": \"Schema representing a user\", \"type\": \"object\", \"additionalProperties\": false, \"properties\": { \"name\": { \"type\": \"string\", \"description\": \"Name of person.\" }, \"email\": { \"type\": \"string\", \"description\": \"email of person.\" }, \"userId\": { \"type\": \"string\", \"description\": \"user id in the system\" } }, \"required\": [\"name\", \"userId\", \"email\"] }";
    @KafkaListener(topics = TOPIC)
    public void consume(String message) {
        System.out.println("Message received: " + message);
    }
}
