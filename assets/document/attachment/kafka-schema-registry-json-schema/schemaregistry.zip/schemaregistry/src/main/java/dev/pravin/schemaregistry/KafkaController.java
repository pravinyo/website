package dev.pravin.schemaregistry;

import dev.pravin.schemaregistry.kafka.KafkaProducer;
import dev.pravin.schemaregistry.model.UserRegistrationTest;
import dev.pravin.schemaregistry.service.KafkaTopicService;
import io.confluent.kafka.schemaregistry.client.rest.exceptions.RestClientException;
import lombok.RequiredArgsConstructor;
import org.springframework.web.bind.annotation.*;

import java.io.IOException;
import java.util.concurrent.ExecutionException;

@RestController
@RequiredArgsConstructor
@RequestMapping("/kafka")
public class KafkaController {
    private final KafkaProducer kafkaProducer;
    private final KafkaTopicService kafkaTopicService;

    @PostMapping("/publish")
    public String publishMessage(@RequestBody UserRegistrationTest userRegistrationTest) throws RestClientException, IOException {
        kafkaProducer.sendMessage(userRegistrationTest);
        return "Message published: " + userRegistrationTest.toString();
    }

    @DeleteMapping("/topic")
    public String delete(@RequestParam String topicName) throws ExecutionException, InterruptedException {
        return kafkaTopicService.deleteTopic(topicName);
    }
}
